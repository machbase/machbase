"""외부 의존성 없이 Ollama HTTP API를 호출한다."""
import json
import math
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def get_generation_options(client, num_ctx=None, num_predict=4096):
    """실제 client 설정을 복사하고 기존 단위 mock에는 호환 기본값을 제공한다."""
    value = getattr(client, "generation_options", None)
    if value is not None:
        return dict(value)
    return dict(temperature=0, num_predict=num_predict, think=False,
                num_ctx=num_ctx if num_ctx is not None else "server-default")


class OllamaClient:
    def __init__(self, url="http://127.0.0.1:11434", timeout=300, num_ctx=None, num_predict=4096):
        if num_ctx is not None and (type(num_ctx) is not int or num_ctx <= 0):
            raise ValueError("num_ctx는 양수 정수 또는 None이어야 합니다")
        if type(num_predict) is not int or num_predict <= 0:
            raise ValueError("num_predict는 양수 정수여야 합니다")
        self.url = url.rstrip("/")
        self.timeout = timeout
        self._num_ctx = num_ctx
        self._num_predict = num_predict
        self._last_usage = {}
        self._last_budget = {}

    @property
    def generation_options(self):
        return dict(temperature=0, num_predict=self._num_predict, think=False,
                    num_ctx=self._num_ctx if self._num_ctx is not None else "server-default")

    @property
    def last_usage(self):
        return {key: dict(value) if isinstance(value, dict) else value for key, value in self._last_usage.items()}

    @property
    def last_budget(self):
        return dict(self._last_budget)

    def input_budget(self, messages, format=None):
        """토크나이저 대신 UTF-8 바이트를 사용하는 보수적 문맥 예산이다."""
        input_bytes = len(json.dumps(messages, ensure_ascii=False).encode("utf-8"))
        schema_bytes = len(json.dumps(format, ensure_ascii=False).encode("utf-8")) if format is not None else 0
        overhead = 64 * (len(messages) + 1)
        upper = input_bytes + schema_bytes + overhead + self._num_predict
        return dict(method="utf8-bytes-conservative-upper-bound", exact_token_count=False,
                    input_utf8_bytes=input_bytes, format_utf8_bytes=schema_bytes, message_overhead=overhead,
                    output_reserve=self._num_predict, total_upper_bound=upper, num_ctx=self._num_ctx,
                    fits=self._num_ctx is None or upper <= self._num_ctx)

    def _request(self, path, payload=None):
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        for attempt in range(3):
            request = Request(self.url + path, data=data, headers={"Content-Type": "application/json"})
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    return json.load(response)
            except HTTPError as error:
                message = error.read().decode("utf-8", errors="replace")[:2000]
                if error.code < 500 or attempt == 2:
                    raise RuntimeError("Ollama " + path + ": " + str(error.code) + " " + message) from error
            except (URLError, TimeoutError, OSError) as error:
                if attempt == 2:
                    raise RuntimeError("Ollama " + path + " 연결 실패: " + str(error)) from error
            time.sleep(attempt + 1)

    def models(self):
        return {item["name"]: item["digest"] for item in self._request("/api/tags")["models"]}

    def embed(self, model, text):
        result = self._request("/api/embed", dict(model=model, input=text, truncate=False,
                                                keep_alive="10m"))
        vector = result["embeddings"][0]
        if not vector or not all(isinstance(value, (int, float)) and math.isfinite(value) for value in vector):
            raise ValueError("Ollama 임베딩이 유한 숫자 배열이 아닙니다")
        return vector

    def chat(self, model, messages, format=None):
        parts = []
        try:
            for part in self.stream(model, messages, format=format):
                parts.append(part)
        except Exception as error:
            error.raw_response = "".join(parts)
            raise
        return "".join(parts)

    def stream(self, model, messages, format=None):
        budget = self.input_budget(messages, format)
        self._last_budget = budget
        self._last_usage = dict(generation_options=self.generation_options, input_budget=budget)
        if self._num_ctx is not None and not budget["fits"]:
            raise ValueError("UTF-8 바이트 기반 보수적 문맥 예산 " + str(budget["total_upper_bound"]) +
                             "이 num_ctx " + str(self._num_ctx) +
                             "를 초과합니다(정확한 토큰 실측 아님). 문맥 크기나 근거 개수를 조정하세요.")
        options = dict(temperature=0, num_predict=self._num_predict)
        if self._num_ctx is not None:
            options["num_ctx"] = self._num_ctx
        payload = dict(model=model, messages=messages, stream=False, think=False, keep_alive="10m",
                       options=options)
        payload["stream"] = True
        if format is not None:
            payload["format"] = format
        request = Request(self.url + "/api/chat", data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                          headers={"Content-Type": "application/json"})
        completed = False
        try:
            with urlopen(request, timeout=self.timeout) as response:
                for line in response:
                    result = json.loads(line)
                    if result.get("error"):
                        raise RuntimeError("Ollama stream: " + str(result["error"]))
                    content = result.get("message", {}).get("content", "")
                    if content:
                        yield content
                    if result.get("done"):
                        self._last_usage = {key: result[key] for key in ("model", "done_reason", "prompt_eval_count",
                            "eval_count", "prompt_eval_duration", "eval_duration", "total_duration", "load_duration") if key in result}
                        self._last_usage["generation_options"] = self.generation_options
                        self._last_usage["input_budget"] = budget
                        if result.get("done_reason") == "length":
                            raise ValueError("Ollama 출력 한도에 도달했습니다. 불완전한 결과는 캐시하지 않습니다")
                        completed = True
                        break
        except HTTPError as error:
            raise RuntimeError("Ollama /api/chat: " + str(error.code) + " " +
                               error.read().decode("utf-8", errors="replace")[:2000]) from error
        if not completed:
            raise RuntimeError("Ollama stream이 완료 marker 없이 종료됐습니다")

    def json(self, model, prompt, system="", format=None):
        messages = ([dict(role="system", content=system)] if system else [])
        messages.append(dict(role="user", content=prompt))
        value = json.loads(self.chat(model, messages, format="json" if format is None else format))
        if not isinstance(value, dict):
            raise ValueError("Ollama JSON 응답은 객체여야 합니다")
        return value
