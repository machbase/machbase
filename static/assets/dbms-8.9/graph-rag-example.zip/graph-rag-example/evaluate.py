"""독립 질문으로 검색 결과를 저장한다. 근거 위치 적중과 의미 판정은 구분한다."""
import json
from pathlib import Path
import time


def source_hit(hits, expected):
    for hit in hits:
        source = str(hit.get('source_path') or hit.get('source_uri','')).removeprefix('file:')
        for ref in expected:
            if source == ref['source_path'] and ref['quote'] in hit.get('body',''):
                return True
    return False


def run(db, client, model, llm_model, output, modes=('direct','graph','hybrid'), language='both'):
    here = Path(__file__).resolve().parent
    gold = {i['id']:i for i in json.loads((here/'gold.json').read_text())['items']}
    questions = []
    if language in ('ko','both'):
        questions += [dict(r,language='ko') for r in json.loads((here/'questions.json').read_text())['questions']]
    if language in ('en','both'):
        questions += [dict(r,language='en') for r in json.loads((here/'questions-en.json').read_text())['questions']]
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    report = {'status':'RUNNING','results':[], 'metrics':{},
              'answer_quality':'NOT_REVIEWED','seed_recall':'NOT_REVIEWED',
              'definition':'source_hit@5는 지정 원문과 인용의 일치이며 의미 판정이 아니다'}
    for number, item in enumerate(questions,1):
        question = item['question']
        from query import prepare
        rewritten,terms,vector=prepare(client,llm_model,model,question)
        seeds=db.discover_seeds(rewritten,vector,terms)
        for mode in modes:
            began=time.perf_counter()
            result=db.search(rewritten,vector,seeds=seeds,mode=mode,top_k=5)
            row={'id':item['id'],'language':item['language'],'question':question,'rewritten':rewritten,'concepts':terms,'mode':mode,'seconds':time.perf_counter()-began,
                 'source_hit@5':source_hit(result['hits'],gold[item['id']]['sources']),
                 'critical':gold[item['id']]['critical_negative'],'retrieval':result}
            report['results'].append(row)
            (output/'evaluation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str))
        print(f'평가 {number}/{len(questions)} {item["id"]}',flush=True)
    for mode in modes:
        rows=[r for r in report['results'] if r['mode']==mode]
        report['metrics'][mode]={'count':len(rows),'source_hit@5':sum(r['source_hit@5'] for r in rows)/len(rows),
                                'critical_source_misses':[r['id'] for r in rows if r['critical'] and not r['source_hit@5']]}
    report['language_metrics']={}
    for lang in ('ko','en'):
        for mode in modes:
            rows=[r for r in report['results'] if r['mode']==mode and r['language']==lang]
            if rows:report['language_metrics'][lang+':'+mode]={'count':len(rows),'source_hit@5':sum(r['source_hit@5'] for r in rows)/len(rows)}
    report['status']='EXECUTED_NOT_SEMANTICALLY_REVIEWED'
    (output/'evaluation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str))
    return report
