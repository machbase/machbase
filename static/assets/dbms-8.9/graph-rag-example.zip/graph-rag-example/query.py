"""대화·검색·실행 계획이 공유하는 질문 분석과 임베딩."""
import json
from contextlib import nullcontext
import re


def refers_to_history(question):
    return bool(re.search(r'그\s*(?:기능|것|경우|작업|값|테이블)|이\s*(?:기능|것|경우|작업|값|테이블)|해당|앞서|위의|이전|\b(?:it|that|this|those|these)\b',question,re.I))


def specific_terms(question, proposed):
    """확인된 복합 개념이 있으면 TAG처럼 포함된 일반어를 seed로 중복 강제하지 않는다."""
    from span_extractor import vocabulary
    from semantic_catalog import EXTRA
    matches=[]
    concepts=list(vocabulary()[0]['concepts'])+[
        dict(canonical_label=label,expressions=[dict(expression=e) for e in [label]+expressions])
        for code,label,category,expressions in EXTRA]
    concepts.append(dict(canonical_label='Distance-axis TAG',expressions=[dict(expression='거리 기반 TAG')]))
    for concept in concepts:
        for entry in concept['expressions']:
            for found in re.finditer(r'(?<![A-Za-z0-9_])'+re.escape(entry['expression'])+r'(?![A-Za-z0-9_])',question,re.I):
                matches.append((found.start(),found.end(),concept['canonical_label']))
    selected=[]
    for candidate in sorted(matches,key=lambda r:-(r[1]-r[0])):
        if not any(candidate[0]<old[1] and old[0]<candidate[1] for old in selected):
            selected.append(candidate)
    terms=[]
    for start,end,label in sorted(selected):
        if label not in terms:
            terms.append(label)
    explicit=set(terms)
    def contained(short,long):
        return bool(re.search(r'(?<![A-Za-z0-9_])'+re.escape(short)+r'(?![A-Za-z0-9_])',long,re.I))
    for term in proposed:
        if not isinstance(term,str):
            continue
        normalized=term.casefold().strip()
        if normalized and not any(contained(normalized,known) for known in terms):
            terms.append(term)
    return [term for term in terms if term in explicit or not any(
        other!=term and len(other)>len(term) and contained(term,other) for other in terms)][:8]


def prepare(client,llm_model,embed_model,question,history=(),progress=None):
    recent=list(history)[-12:]
    instruction=('\n현재 질문: '+question+'\n문맥을 반영한 독립 검색 질문과 질문에 있는 기술 개념/식별자를 '
        '{"question":"...","concepts":["..."]}으로 반환하세요. 대화의 사실을 정답으로 단정하지 마세요. '
        '가능 여부 질문을 방법 질문으로 바꾸지 마세요. 부정·조건·숫자·언어를 보존하세요.')
    options=getattr(client,'generation_options',{})
    context=options.get('num_ctx')
    if isinstance(context,int):
        reserve=options.get('num_predict',4096)+1024
        while recent and len((json.dumps(recent,ensure_ascii=False)+instruction).encode())+reserve>context:
            recent=recent[2:]
        if history and not recent:
            raise ValueError('대화 문맥이 예산을 넘었습니다. --llm-context를 늘리거나 /clear 후 대상 개념을 명시하세요')
    client.last_query_context={'history_messages_used':len(recent),'history_messages_omitted':len(history)-len(recent)}
    with progress.stage('1. 질문 분석 · LLM') if progress else nullcontext():
        data=client.json(llm_model,json.dumps(recent,ensure_ascii=False)+instruction)
    # 첫 질문은 문맥 해소가 필요 없으며 모델 재서술이 가능 여부를 단정할 수 있다.
    rewritten=(data.get('question') or question) if history and refers_to_history(question) else question
    # 현재 질문에 대상이 명시되면 이전 대화의 다른 기능을 끌어오지 않는다.
    if specific_terms(question,[]):rewritten=question
    if not isinstance(rewritten,str) or not rewritten.strip():
        raise ValueError('질문 분석 결과가 비어 있거나 문자열이 아닙니다')
    terms=data.get('concepts',[])
    if not isinstance(terms,list):
        raise ValueError('질문 분석 concepts가 배열이 아닙니다')
    terms=specific_terms(rewritten,terms)
    with progress.stage('2. 질문 임베딩') if progress else nullcontext():
        vector=client.embed(embed_model,rewritten)
    return rewritten,terms,vector
