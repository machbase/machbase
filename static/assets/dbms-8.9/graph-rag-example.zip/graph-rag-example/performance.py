"""동일 질문·코퍼스의 실제 검색 시간과 SQL 실행 계획을 보존한다."""
import json
from pathlib import Path
import statistics
import time


def run(db, client, model, questions, output, repeats=5, llm_model="qwen3.5:9b"):
    output = Path(output)
    output.mkdir(parents=True,exist_ok=True)
    report = {'repeats':repeats,'results':[], 'note':'EXACT 후보 읽기와 구조 JOIN FULL SCAN은 구분한다.'}
    for number, question in enumerate(questions,1):
        preparation_started=time.perf_counter()
        from query import prepare
        rewritten,terms,vector=prepare(client,llm_model,model,question)
        seeds=db.discover_seeds(rewritten,vector,terms)
        preparation_seconds=time.perf_counter()-preparation_started
        for mode in ('direct','graph','hybrid'):
            measurements=[]
            for _ in range(repeats+1):
                start=time.perf_counter()
                result=db.search(rewritten,vector,seeds=seeds,mode=mode)
                measurements.append(time.perf_counter()-start)
            plan=db.explain_search(rewritten,vector,seeds=seeds,mode=mode,full=True)
            warm=sorted(measurements[1:])
            row={'question':question,'rewritten':rewritten,'concepts':terms,'mode':mode,'question_preparation_seconds':preparation_seconds,
                 'timing_scope':'DB retrieval with precomputed embedding and seeds; preparation measured separately','cold_seconds':measurements[0],
                 'warm_seconds':measurements[1:],'p50_seconds':statistics.median(warm),
                 'p95_seconds':warm[-1], 'hits':len(result.get('hits',[])), 'plan':plan}
            report['results'].append(row)
            (output/'performance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str))
            print(f'성능 {number}/{len(questions)} {mode}: {row["p50_seconds"]:.3f}s',flush=True)
    return report
