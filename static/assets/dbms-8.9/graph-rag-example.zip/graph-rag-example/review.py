"""서버 없이 열 수 있는 온톨로지/근거 검토 자료를 같은 ID로 내보낸다."""
import copy
import html
import json
import unicodedata
from pathlib import Path


def _esc(value):
    return html.escape(str(value), quote=True)


def _cell(value):
    return _esc(value).replace("|", "&#124;").replace("\n", "<br>")


def _browser(value):
    # 모든 정수를 문자열로 보존한다. JS Number로 INT64 ID를 반올림하지 않는다.
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return [_browser(v) for v in value]
    if isinstance(value, dict):
        return {k: _browser(v) for k, v in value.items()}
    return value


def _key(value):
    return str(value) if value is not None else ""


def _context(evidence, chunk):
    body, quote = str(chunk.get("body") or ""), str(evidence.get("quote") or "")
    begin = body.find(quote) if quote else -1
    first = int(chunk.get("line_start") or 1)
    if begin < 0:
        return dict(valid=False, line_start=first, line_end=int(chunk.get("line_end") or first),
                    context=body, quote=quote)
    before = body[:begin].count("\n")
    end = before + max(0, len(quote.splitlines()) - 1)
    lines = body.splitlines()
    lo, hi = max(0, before - 2), min(len(lines), end + 3)
    return dict(valid=True, line_start=first + before, line_end=first + end,
                context_line_start=first + lo, context="\n".join(lines[lo:hi]), quote=quote)


def _prepare(snapshot):
    data = copy.deepcopy(snapshot)
    for name in ("documents", "chunks", "nodes", "edges", "evidence", "issues"):
        data.setdefault(name, [])
    data.setdefault("manifest", {})
    chunks = {_key(c.get("chunk_id")): c for c in data["chunks"]}
    docs = {_key(d.get("document_id")): d for d in data["documents"]}
    nodes = {_key(n.get("node_id")): n for n in data["nodes"]}
    edges = {_key(e.get("edge_id")): e for e in data["edges"]}
    review_issues = []
    aliases = {}
    for node in data['nodes']:
        if node.get('node_kind') == 'ALIAS' and node.get('state') == 'PUBLISHED':
            key = ' '.join(unicodedata.normalize('NFC',str(node.get('label_key') or node.get('label',''))).casefold().split())
            aliases.setdefault(key,set()).add(_key(node.get('canonical_id')))
    for key, canonical in sorted(aliases.items()):
        if len(canonical) > 1:
            review_issues.append(dict(kind='AMBIGUOUS_ALIAS_CANONICAL', label_key=key, canonical_ids=sorted(canonical)))
    sources = []
    for evidence in data["evidence"]:
        eid = _key(evidence.get("evidence_id"))
        cid = _key(evidence.get("chunk_id"))
        chunk = chunks.get(cid, {})
        document = docs.get(_key(chunk.get("document_id")), {})
        context = _context(evidence, chunk)
        target = nodes if evidence.get("target_kind") == "NODE" else edges
        if evidence.get("target_kind") not in ("NODE", "EDGE") or _key(evidence.get("target_id")) not in target:
            review_issues.append(dict(kind="DANGLING_EVIDENCE_TARGET", evidence_id=evidence.get("evidence_id")))
        if not chunk:
            review_issues.append(dict(kind="MISSING_CHUNK", evidence_id=evidence.get("evidence_id"), chunk_id=evidence.get("chunk_id")))
        if not document:
            review_issues.append(dict(kind="MISSING_DOCUMENT", evidence_id=evidence.get("evidence_id")))
        if not context["valid"]:
            review_issues.append(dict(kind="QUOTE_NOT_IN_CHUNK", evidence_id=evidence.get("evidence_id")))
        sources.append(dict(evidence, **context,
                            source_path=chunk.get("source_path") or document.get("source_uri") or "출처 미상",
                            document_id=chunk.get("document_id"), document_title=document.get("title", "")))
    for edge in data["edges"]:
        for name in ("source_id", "predicate_id", "target_id"):
            if _key(edge.get(name)) not in nodes:
                review_issues.append(dict(kind="DANGLING_EDGE_NODE", edge_id=edge.get("edge_id"), field=name))
    data["review_sources"] = sources
    data["review_issues"] = review_issues
    return data


def _table(columns, items, name):
    head = "".join("<th>" + _esc(title) + "</th>" for key, title in columns)
    return ('<div data-table="' + _esc(name) + '" data-columns="' + _esc(json.dumps(columns,ensure_ascii=False)) +
            '"><button class=table-prev>이전 목록</button><span class=table-count></span>' +
            '<button class=table-next>다음 목록</button><div class=scroll><table><thead><tr>' +
            head + '</tr></thead><tbody></tbody></table></div></div>')


STYLE = """*{box-sizing:border-box}#node{display:block;width:100%;min-width:0;margin:4px 0}body{font:15px/1.55 system-ui,sans-serif;max-width:1300px;margin:auto;padding:24px;color:#173047;background:#f6f8fa}h1,h2{line-height:1.3}input,select,button{font:inherit;padding:8px;margin:4px}input{min-width:260px}section,.panel{background:white;padding:18px;border:1px solid #d7dfe7;border-radius:8px;margin:18px 0}.scroll{overflow:auto;max-height:520px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;vertical-align:top;padding:8px;border-bottom:1px solid #ddd;white-space:pre-wrap;overflow-wrap:anywhere}th{position:sticky;top:0;background:#edf2f6}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 ui-monospace,monospace}svg{width:100%;min-height:440px;background:#f8fafc}svg text{font:12px system-ui,sans-serif}svg g{cursor:pointer}a{color:#075caa}.hint{color:#526578}#selection{max-height:500px;overflow:auto}button:focus,input:focus,select:focus{outline:3px solid #469be5}summary{cursor:pointer} .edge{color:#6d4487} .bad{color:#ad2e24}"""

SCRIPT = r"""'use strict';
const data=JSON.parse(document.getElementById('snapshot').textContent);
const nodes=new Map(data.nodes.map(n=>[n.node_id,n]));
const edges=data.edges, sources=data.review_sources;
const select=document.getElementById('node');
const svg=document.getElementById('graph');
const detail=document.getElementById('selection');
const ns='http://www.w3.org/2000/svg';
let graphPage=0;
function el(tag,attrs={},text=''){const n=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,v);n.textContent=text;return n;}
function paragraph(parent,text,tag='p'){const p=document.createElement(tag);p.textContent=text;parent.append(p);return p;}
function paged(parent,items,render,title){
 const controls=document.createElement('div'),previous=document.createElement('button'),next=document.createElement('button'),count=document.createElement('span'),body=document.createElement('div');
 previous.textContent='이전 '+title;next.textContent='다음 '+title;controls.append(previous,count,next);parent.append(controls,body);let page=0;
 function show(){body.replaceChildren();for(const item of items.slice(page*20,(page+1)*20))render(body,item);count.textContent=`${title} ${items.length}개 · ${page+1}/${Math.max(1,Math.ceil(items.length/20))}쪽`;previous.disabled=page===0;next.disabled=(page+1)*20>=items.length;}
 previous.addEventListener('click',()=>{page--;show();});next.addEventListener('click',()=>{page++;show();});show();
}
function inspect(id){
 const node=nodes.get(id);detail.replaceChildren();if(!node)return;
 paragraph(detail,`${node.label} · ID ${id} · ${node.node_kind} · ${node.state}`,'h3');
 paragraph(detail,node.description||'설명 없음');
 if(node.canonical_id)paragraph(detail,`정규 개념: ${nodes.get(node.canonical_id)?.label||'미등록'} [${node.canonical_id}]`);
 const related=edges.filter(e=>e.source_id===id||e.target_id===id);
 const targets=new Set(related.map(e=>e.edge_id));
 paged(detail,related,(parent,e)=>{paragraph(parent,`관계 ${e.edge_id}: ${nodes.get(e.source_id)?.label||e.source_id} → ${nodes.get(e.predicate_id)?.code||nodes.get(e.predicate_id)?.label||e.predicate_id} → ${nodes.get(e.target_id)?.label||e.target_id} (${e.state})`);},'관계');
 paged(detail,sources.filter(s=>(s.target_kind==='NODE'&&s.target_id===id)||(s.target_kind==='EDGE'&&targets.has(s.target_id))),(parent,s)=>{
  const box=document.createElement('details');box.open=true;parent.append(box);
  paragraph(box,`근거 ${s.evidence_id} · ${s.target_kind} ${s.target_id} · ${s.source_path}:${s.line_start}-${s.line_end}`,'summary');
  paragraph(box,`인용: ${s.quote}`,'blockquote');
  paragraph(box,`문맥 (${s.context_line_start||s.line_start}행부터):
${s.context}`,'pre');
  if(!s.valid)paragraph(box,'검토 필요: 인용이 청크의 정확한 부분 문자열이 아닙니다.');
 },'근거');
}
function inspectEdge(id){
 const edge=edges.find(e=>e.edge_id===id);if(!edge)return;detail.replaceChildren();
 paragraph(detail,`관계 ID ${id} · ${edge.state}`,'h3');
 paragraph(detail,`${nodes.get(edge.source_id)?.label||edge.source_id} [${edge.source_id}] → ${nodes.get(edge.predicate_id)?.code||edge.predicate_id} [${edge.predicate_id}] → ${nodes.get(edge.target_id)?.label||edge.target_id} [${edge.target_id}]`);
 if(edge.scope_json){const box=document.createElement('details');detail.append(box);paragraph(box,'명제 범위·조건·대조 원문','summary');try{paragraph(box,JSON.stringify(JSON.parse(edge.scope_json),null,2),'pre');}catch(error){paragraph(box,'검토 필요: scope JSON 형식 오류');}}
 const proofs=sources.filter(s=>s.target_kind==='EDGE'&&s.target_id===id);
 if(!proofs.length)paragraph(detail,'검토 필요: 연결된 원문 근거가 없습니다.');
 for(const s of proofs){paragraph(detail,`근거 ${s.evidence_id} · chunk ${s.chunk_id} · ${s.source_path}:${s.line_start}-${s.line_end}`,'h4');paragraph(detail,s.quote,'blockquote');paragraph(detail,`문맥 (${s.context_line_start||s.line_start}행부터):\n${s.context}`,'pre');if(!s.valid)paragraph(detail,'검토 필요: 원문 인용이 일치하지 않습니다.');}
}
function draw(){
 const id=select.value,depth=Number(document.getElementById('hops').value);svg.replaceChildren();
 if(!nodes.has(id))return;
 const reachable=new Set([id]),parent=new Map();let frontier=new Set([id]);
 for(let i=0;i<depth;i++){const next=new Set();for(const e of edges){for(const [a,b]of [[e.source_id,e.target_id],[e.target_id,e.source_id]])if(frontier.has(a)&&nodes.has(b)&&!reachable.has(b)){reachable.add(b);parent.set(b,a);next.add(b);}}frontier=next;}
 const neighbors=[...reachable].filter(n=>n!==id),pages=Math.max(1,Math.ceil(neighbors.length/8));
 graphPage=Math.max(0,Math.min(graphPage,pages-1));
 const visible=new Set([id]);for(const n of neighbors.slice(graphPage*8,graphPage*8+8)){let p=n;while(p&&p!==id){visible.add(p);p=parent.get(p);}}
 const list=[...visible],width=1100,height=Math.max(500,Math.ceil((list.length-1)/2)*90+100),pos=new Map();
 document.getElementById('graph-prev').disabled=graphPage===0;document.getElementById('graph-next').disabled=graphPage===pages-1;
 document.getElementById('graph-page').textContent=`이웃 ${neighbors.length}개 · ${graphPage+1}/${pages}쪽 (연결에 필요한 중간 노드 포함)`;
 svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
 const defs=el('defs'),marker=el('marker',{id:'arrow',viewBox:'0 0 10 10',refX:10,refY:5,markerWidth:7,markerHeight:7,orient:'auto-start-reverse'});marker.append(el('path',{d:'M 0 0 L 10 5 L 0 10 z',fill:'#9aa9b8'}));defs.append(marker);svg.append(defs);
 list.forEach((n,i)=>pos.set(n,i===0?[width/2,height/2]:[(i%2)?180:920,70+Math.floor((i-1)/2)*90]));
 for(const e of edges){
  if(!visible.has(e.source_id)||!visible.has(e.target_id))continue;
  const [x1,y1]=pos.get(e.source_id),[x2,y2]=pos.get(e.target_id),length=Math.hypot(x2-x1,y2-y1)||1;
  const line=el('line',{x1,y1,x2:x2-25*(x2-x1)/length,y2:y2-25*(y2-y1)/length,stroke:e.state==='APPROVED'?'#6f8d9c':'#b7791f','stroke-dasharray':e.state==='APPROVED'?'':'6 4','stroke-width':3,'marker-end':'url(#arrow)','data-edge-id':e.edge_id});
  const label=el('text',{x:(x1+x2)/2,y:(y1+y2)/2,fill:'#735183','text-anchor':'middle',opacity:0,tabindex:0,role:'button','aria-label':`관계 ${e.edge_id} 근거 보기`},`${nodes.get(e.predicate_id)?.code||nodes.get(e.predicate_id)?.label||e.predicate_id} [${e.edge_id}]`);
  const choose=()=>inspectEdge(e.edge_id);line.style.cursor='pointer';label.style.cursor='pointer';line.addEventListener('click',choose);label.addEventListener('click',choose);label.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();choose();}});
  line.addEventListener('mouseenter',()=>label.setAttribute('opacity',1));line.addEventListener('mouseleave',()=>label.setAttribute('opacity',0));label.addEventListener('focus',()=>label.setAttribute('opacity',1));label.addEventListener('blur',()=>label.setAttribute('opacity',0));
  svg.append(line,label);
 }
 for(const n of list){const [x,y]=pos.get(n),item=nodes.get(n),g=el('g',{tabindex:0,role:'button','aria-label':item.label});g.append(el('circle',{cx:x,cy:y,r:n===id?25:18,fill:n===id?'#1468ac':item.state==='PUBLISHED'?'#397b64':'#b7791f'}));g.append(el('text',{x,y:y+42,'text-anchor':'middle',fill:'#173047'},item.label.length>30?item.label.slice(0,29)+'…':item.label));g.append(el('title',{},`${item.label} ID=${n}`));const choose=()=>{select.value=n;graphPage=0;draw();};g.addEventListener('click',choose);g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose();}});svg.append(g);}
 document.getElementById('graph-count').textContent=`선택 ${id} · ${depth} hop · 개념 ${list.length}개. 관계는 source → target 방향입니다. 전체 목록에서 원래 ID와 근거를 확인하세요.`;
 inspect(id);
}
for(const n of data.nodes){const o=document.createElement('option');o.value=n.node_id;o.textContent=`${n.label} [${n.node_kind}] ${n.node_id}`;select.append(o);}
const initial=data.nodes.find(n=>!['ALIAS','RELATION_TYPE'].includes(n.node_kind));if(initial)select.value=initial.node_id;
select.addEventListener('change',()=>{graphPage=0;draw();});document.getElementById('hops').addEventListener('change',()=>{graphPage=0;draw();});
document.getElementById('graph-prev').addEventListener('click',()=>{graphPage--;draw();});document.getElementById('graph-next').addEventListener('click',()=>{graphPage++;draw();});
function tableValue(row,key){if(['source','predicate','target'].includes(key)){const id=row[key+'_id'];return `${nodes.get(id)?.label||''} [${id}]`;}return row[key]??'';}
const tables=Array.from(document.querySelectorAll('[data-table]')).map(panel=>{
 const columns=JSON.parse(panel.dataset.columns),rows=data[panel.dataset.table],body=panel.querySelector('tbody'),previous=panel.querySelector('.table-prev'),next=panel.querySelector('.table-next'),count=panel.querySelector('.table-count');
 const search=rows.map(row=>columns.map(([key])=>String(tableValue(row,key))).join(' ').toLowerCase());let filtered=rows,page=0;
 function show(){body.replaceChildren();for(const row of filtered.slice(page*50,(page+1)*50)){const tr=document.createElement('tr');tr.dataset.search='';for(const [key]of columns){const td=document.createElement('td');td.textContent=String(tableValue(row,key));tr.append(td);}
  let activate;
  if(panel.dataset.table==='nodes'){tr.dataset.tableNodeId=row.node_id;activate=()=>{select.value=row.node_id;graphPage=0;draw();};}
  if(panel.dataset.table==='edges'){tr.dataset.tableEdgeId=row.edge_id;activate=()=>{select.value=row.source_id;graphPage=0;draw();inspectEdge(row.edge_id);};}
  if(activate){tr.tabIndex=0;tr.title='클릭 또는 Enter로 그래프·근거 확인';tr.style.cursor='pointer';const open=()=>{activate();detail.scrollIntoView({block:'nearest'});};tr.addEventListener('click',open);tr.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});}
  body.append(tr);}count.textContent=`일치 ${filtered.length}행 · ${page+1}/${Math.max(1,Math.ceil(filtered.length/50))}쪽`;previous.disabled=page===0;next.disabled=(page+1)*50>=filtered.length;}
 previous.addEventListener('click',()=>{page--;show();});next.addEventListener('click',()=>{page++;show();});show();
 return {filter:q=>{filtered=rows.filter((row,index)=>search[index].includes(q));page=0;show();return filtered.length;}};
});
document.getElementById('search').addEventListener('input',event=>{const q=event.target.value.toLowerCase();const count=tables.reduce((sum,table)=>sum+table.filter(q),0);document.getElementById('search-count').textContent=`전체 일치 ${count}행`;});draw();
"""


def export_review(snapshot, out: Path):
    """review.html/.md/.json을 만들고 실제 경로 dict를 반환한다. snapshot은 바꾸지 않는다."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    data = _prepare(snapshot)
    paths = {name: out / ("review." + ext) for name, ext in (("html", "html"), ("markdown", "md"), ("json", "json"))}
    paths["json"].write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    issues = data["issues"] + data["review_issues"]
    node_rows = [{**n, "canonical_id": n.get("canonical_id", "")} for n in data["nodes"]]
    node_labels = {_key(n.get("node_id")): n.get("label", "") for n in data["nodes"]}
    edge_rows = [{**e, "source": node_labels.get(_key(e.get("source_id")), "") + " [" + _key(e.get("source_id")) + "]",
                  "predicate": node_labels.get(_key(e.get("predicate_id")), "") + " [" + _key(e.get("predicate_id")) + "]",
                  "target": node_labels.get(_key(e.get("target_id")), "") + " [" + _key(e.get("target_id")) + "]"} for e in data["edges"]]
    # SVG/목록 검토에는 embedding이 필요 없다. raw JSON은 그대로 보존한다.
    browser_data = {name: [{key: value for key, value in row.items() if key != "embedding"}
                          for row in data[name]] for name in ("nodes", "edges", "review_sources")}
    encoded = json.dumps(_browser(browser_data), ensure_ascii=False).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    screening = data['manifest'].get('semantic_validation', {})
    stage = ('원문 관계 명세 검토 완료 · 사람 독립 판정 별도' if screening.get('agent_reviewed') else
             '모델 문맥 검사 완료 · 사람 의미 판정 별도') if screening.get('complete') else '추출 초안 · 문맥 검사 미완료'
    completed = sum(c.get('analysis_state') == 'COMPLETE' for c in data['chunks'])
    summary = f"입력 문서 {len(data['documents'])}개 · 처리 완료 청크 {completed}/{len(data['chunks'])}개 · 노드 {len(data['nodes'])}개 · 관계 {len(data['edges'])}개 · 근거 {len(data['evidence'])}개"
    sections = ["<!doctype html><html lang=ko><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>온톨로지 근거 검토</title><style>" + STYLE + "</style><body>",
                "<h1>온톨로지·근거 검토</h1><p class=hint>로컬 파일만으로 동작합니다. 이 화면은 추출 결과의 검토 자료이며 의미 정확성의 자동 합격 판정이 아닙니다.</p>",
                '<p><strong>검토 단계: ' + _esc(stage) + '</strong></p>',
                '<p>' + _esc(summary) + '</p>',
                "<label for=search>전체 목록 검색</label><input id=search type=search placeholder='개념 · 관계 · 원문 · ID'><output id=search-count aria-live=polite></output>",
                '<section><h2>선택 개념의 이웃</h2><label for=node>개념</label><select id=node></select><label for=hops>범위</label><select id=hops><option value=1>1 hop</option><option value=2>2 hop</option></select><p id=graph-count></p><p class=hint>초록: 게시 노드 · 갈색: 미게시 노드/검토 관계 · 파랑: 현재 선택 · 점선: REVIEW. 승인 표시는 의미 품질 인증이 아닙니다.</p><button id=graph-prev>이전 이웃</button><span id=graph-page></span><button id=graph-next>다음 이웃</button><svg id=graph role=img aria-label="선택 개념의 관계 그래프"></svg><div id=selection></div></section>',
                "<section><h2>개념·별칭·관계 유형</h2>" + _table([("node_id", "ID"), ("node_kind", "유형"), ("label", "이름"), ("code", "code"), ("state", "상태"), ("description", "설명"), ("canonical_id", "정규 ID")], node_rows, "nodes") + "</section>",
                "<section><h2>관계</h2>" + _table([("edge_id", "ID"), ("source", "출발"), ("predicate", "관계 유형"), ("target", "도착"), ("state", "상태")], edge_rows, "edges") + "</section>",
                "<section><h2>출처와 인용</h2>" + _table([("evidence_id", "근거 ID"), ("target_kind", "대상 유형"), ("target_id", "대상 ID"), ("chunk_id", "청크 ID"), ("source_path", "파일"), ("line_start", "시작 행"), ("line_end", "끝 행"), ("quote", "정확 인용"), ("context", "주변 문맥")], data["review_sources"], "review_sources") + "</section>",
                "<section><h2>검토 필요 항목</h2><pre>" + _esc(json.dumps(issues, ensure_ascii=False, indent=2)) + "</pre></section>",
                "<section><h2>구축 명세</h2><pre>" + _esc(json.dumps(data["manifest"], ensure_ascii=False, indent=2)) + "</pre></section>",
                '<script id=snapshot type=application/json>' + encoded + "</script><script>" + SCRIPT + "</script></body></html>"]
    paths["html"].write_text("\n".join(sections), encoding="utf-8")
    md = ["# 온톨로지·근거 검토", "", "원문 및 근거 ID를 기준으로 검토합니다. 정적 export는 의미 품질 합격 판정이 아닙니다.", "", "## 개념", "", "| ID | 유형 | 이름 | code | 상태 | 설명 |", "|---|---|---|---|---|---|"]
    for n in data["nodes"]:
        md.append("| " + " | ".join(_cell(n.get(k, "")) for k in ("node_id", "node_kind", "label", "code", "state", "description")) + " |")
    md += ["", "## 관계", "", "| ID | 출발 | 유형 | 도착 | 상태 |", "|---|---|---|---|---|"]
    for edge in edge_rows:
        md.append("| " + " | ".join(_cell(edge.get(k, "")) for k in ("edge_id", "source", "predicate", "target", "state")) + " |")
    md += ["", "## 출처와 인용"]
    for s in data["review_sources"]:
        md += ["", "### 근거 " + _cell(s.get("evidence_id")), "", _cell(f'{s.get("target_kind")} {s.get("target_id")} · chunk {s.get("chunk_id")} · {s["source_path"]}:{s["line_start"]}-{s["line_end"]}'), "", "> " + _cell(s["quote"]), "", "문맥:", "", _cell(s["context"])]
    md += ["", "## 검토 필요 항목", "", _cell(json.dumps(issues, ensure_ascii=False, indent=2)), "", "## 구축 명세", "", _cell(json.dumps(data["manifest"], ensure_ascii=False, indent=2)), ""]
    paths["markdown"].write_text("\n".join(md), encoding="utf-8")
    return paths
