"""에이전트가 선별한 실제 원문의 native SQL smoke. import 시 외부 호출은 없다."""
from collections import Counter, defaultdict
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

from db import Database, _vector, snapshot_hash

HERE = Path(__file__).resolve().parent
ROLE = 'agent-curated smoke fixture, not full ontology quality/human approval'
VERSION = 'fixture1'
BASE = 9007199254740992
QUERY = 'TAG DATA UPDATE는 어떤 Edition에서 사용하며 SET 우변에서 기존 컬럼을 참조할 수 있나요?'
DOMAIN = {'PART_OF', 'REQUIRES', 'APPLIES_TO', 'SUPPORTS', 'LIMITED_BY', 'RELATED_TO'}


def _sha(value):
    data = value if isinstance(value, bytes) else value.encode('utf-8')
    return hashlib.sha256(data).hexdigest()


def _passage(name, first, last):
    path = HERE / 'doc' / name
    raw = path.read_bytes()
    lines = raw.decode('utf-8').splitlines(keepends=True)
    if not 1 <= first <= last <= len(lines):
        raise ValueError('smoke 원문 줄 범위가 달라졌습니다: ' + name)
    return dict(source_path=name, line_start=first, line_end=last,
                source_sha256=_sha(raw), body=''.join(lines[first - 1:last]))


def fixture(client, model):
    """root가 제공한 실제 Ollama client로 BGE 임베딩을 만든다. 임의 벡터 대체는 없다."""
    models = client.models()
    if model not in models:
        raise ValueError('smoke 임베딩 모델을 Ollama에서 확인하지 못했습니다')
    passages = [
        _passage('tag-data-update-correction.kr.md', 8, 10),
        _passage('tag-data-update-correction.kr.md', 16, 19),
        _passage('tag-metadata.kr.md', 75, 89),
        _passage('tag-metadata.kr.md', 246, 249),
    ]
    quotes = dict(update=passages[0]['body'],
                  edition=_passage('tag-data-update-correction.kr.md', 10, 10)['body'].rstrip('\n'),
                  restriction=_passage('tag-data-update-correction.kr.md', 16, 17)['body'].rstrip('\n'),
                  array=_passage('tag-metadata.kr.md', 80, 82)['body'].rstrip('\n'),
                  scalar=_passage('tag-metadata.kr.md', 248, 248)['body'].rstrip('\n'))
    if ('Standard Edition' not in quotes['edition'] or '기존 행 컬럼을 참조할 수 없으므로' not in quotes['restriction'] or
        'index도 지원하지 않습니다' not in quotes['array'] or '인덱스가 자동으로 제공됩니다' not in quotes['scalar']):
        raise ValueError('smoke가 선별한 원문 명제가 변경되었습니다. fixture를 다시 검토하세요')
    documents, chunks, nodes, edges, evidence = [], [], [], [], []
    doc_ids = {}
    for passage in passages:
        name = passage['source_path']
        if name not in doc_ids:
            doc_ids[name] = BASE + 1 + len(doc_ids)
            documents.append(dict(document_id=doc_ids[name], kb_id=1, title=name,
                                  source_uri='file:' + name, current_version=1, state='PUBLISHED',
                                  external_key=name, source_sha256=passage['source_sha256']))
        chunk_id = BASE + 101 + len(chunks)
        chunks.append(dict(chunk_id=chunk_id, kb_id=1, document_id=doc_ids[name], document_version=1,
                           ordinal=1 + sum(row['document_id'] == doc_ids[name] for row in chunks),
                           locator=f"{name}:L{passage['line_start']}-L{passage['line_end']}",
                           body=passage['body'], embedding=_vector(client.embed(model, passage['body'])),
                           analysis_state='COMPLETE', extractor_version=VERSION, fact_count=0,
                           **{key: value for key, value in passage.items() if key != 'body'}))

    def proof(kind, target, chunk, quote):
        if not quote or quote not in chunks[chunk]['body'] or len(quote.encode()) > 2048:
            raise ValueError('smoke 인용이 원문 또는 SQL quote 크기와 맞지 않습니다')
        evidence.append(dict(evidence_id=BASE + 401 + len(evidence), kb_id=1,
                             target_kind=kind, target_id=target, chunk_id=chunks[chunk]['chunk_id'], quote=quote))

    def node(label, quote, chunk, kind='ENTITY', **extra):
        identity = BASE + 201 + len(nodes)
        search_text = label + '\n' + quote if kind == 'ENTITY' else None
        row = dict(node_id=identity, kb_id=1, node_kind=kind, label=label, code=None,
                   description=quote or None, search_text=search_text, state='PUBLISHED',
                   embedding=_vector(client.embed(model, search_text)) if search_text else None,
                   canonical_id=None, label_key=label.casefold(), source_kind=None, target_kind=None)
        row.update(extra)
        nodes.append(row)
        if quote:
            proof('NODE', identity, chunk, quote)
        return identity

    update = node('TAG DATA UPDATE', quotes['update'], 0)
    edition = node('Machbase DBMS 8.7.0 Standard Edition', quotes['edition'], 0)
    restriction = node('SET 우변의 기존 행 컬럼 참조 금지', quotes['restriction'], 1)
    node('ARRAY metadata 컬럼의 자동 및 명시 인덱스 미지원', quotes['array'], 2)
    node('_LAST_UPDATE_TIME 시간 조건 자동 인덱스', quotes['scalar'], 3)
    node('TAG DATA UPDATE', quotes['update'], 0, kind='ALIAS', canonical_id=update)
    for code, target, chunk, quote in [('REQUIRES', edition, 0, quotes['update']),
                                       ('LIMITED_BY', restriction, 1, quotes['restriction'])]:
        predicate = node(code, '', chunk, kind='RELATION_TYPE', code=code,
                         source_kind='ENTITY', target_kind='ENTITY')
        edge_id = BASE + 301 + len(edges)
        edges.append(dict(edge_id=edge_id, kb_id=1, source_id=update, predicate_id=predicate,
                          target_id=target, state='APPROVED', subject_text='TAG DATA UPDATE',
                          predicate_text=code, object_text=next(row['label'] for row in nodes if row['node_id'] == target),
                          extractor_version=VERSION, canonical_edge_id=None))
        proof('EDGE', edge_id, chunk, quote)
    for chunk in chunks:
        chunk['fact_count'] = sum(row['target_kind'] == 'EDGE' and row['chunk_id'] == chunk['chunk_id'] for row in evidence)
    source_identity = json.dumps([dict(path=row['source_path'], first=row['line_start'], last=row['line_end'],
                                      sha256=row['source_sha256'], body_sha256=_sha(row['body'])) for row in passages],
                                 ensure_ascii=False, sort_keys=True)
    manifest = dict(complete=True, role=ROLE, fixture_version=VERSION,
                    embedding=dict(model=model, digest=models[model], dimensions=1024, normalization='L2'),
                    files=[dict(path=name, sha256=next(row['source_sha256'] for row in passages if row['source_path'] == name)) for name in doc_ids],
                    semantic_validation=dict(complete=True, model='agent-curation-smoke', digest=_sha(source_identity),
                                             validator_version=VERSION, human_reviewed=False))
    result = dict(documents=documents, chunks=chunks, nodes=nodes, edges=edges, evidence=evidence,
                  issues=[dict(role=ROLE, reason='에이전트가 명시한 원문 두 관계의 SQL smoke이며 전체 온톨로지 품질·사람 승인이 아니다')],
                  manifest=manifest, smoke=dict(question=QUERY, query_vector=_vector(client.embed(model, QUERY)),
                                               required_seed=update, required_edge=edges[1]['edge_id']))
    # 필드·ID·인용·모델 경계를 실제 적재와 같은 사전검증으로 확인한다. DB 연결은 없다.
    Database.__new__(Database)._validate_snapshot(result)
    return result


def _expected(snapshot, seeds, depth):
    """검색 SQL/DB 결과를 사용하지 않는 작은 경로·근거 집합 oracle."""
    documents = {row['document_id']: row for row in snapshot['documents'] if row['state'] == 'PUBLISHED'}
    chunks = {row['chunk_id']: row for row in snapshot['chunks'] if row['document_id'] in documents and
              row['document_version'] == documents[row['document_id']]['current_version']}
    proofs = defaultdict(list)
    for row in snapshot['evidence']:
        if row['chunk_id'] in chunks:
            proofs[(row['target_kind'], row['target_id'])].append(row)
    nodes = {row['node_id']: row for row in snapshot['nodes'] if row['node_kind'] == 'ENTITY' and
             row['state'] == 'PUBLISHED' and proofs[('NODE', row['node_id'])]}
    predicates = {row['node_id']: row for row in snapshot['nodes'] if row['node_kind'] == 'RELATION_TYPE'}
    adjacency = defaultdict(list)
    for row in snapshot['edges']:
        predicate = predicates[row['predicate_id']]
        if (row['state'] != 'APPROVED' or row['source_id'] not in nodes or row['target_id'] not in nodes or
            not proofs[('EDGE', row['edge_id'])] or predicate['state'] != 'PUBLISHED' or predicate['code'] not in DOMAIN or
            predicate['source_kind'] != nodes[row['source_id']]['node_kind'] or
            predicate['target_kind'] != nodes[row['target_id']]['node_kind']):
            continue
        for direction, first, last in [('F', row['source_id'], row['target_id']), ('R', row['target_id'], row['source_id'])]:
            adjacency[first].append((last, row, predicate['code'], direction))
    walks = []
    for seed in sorted(set(row['node_id'] for row in seeds) & set(nodes)):
        pending = [(seed, (seed,), (), '@')]
        while pending:
            current, visited, steps, route = pending.pop()
            walks.append(dict(seed=seed, node=current, steps=steps, route=route, depth=len(steps)))
            if len(steps) == depth:
                continue
            for target, edge, code, direction in adjacency[current]:
                if target not in visited:
                    step = (current, edge['edge_id'], edge['predicate_id'], code, target, direction)
                    pending.append((target, visited + (target,), steps + (step,),
                                    route + '/' + f"{edge['edge_id']:019d}" + direction))
    best = {}
    for walk in walks:
        key = walk['seed'], walk['node']
        if key not in best or (walk['depth'], walk['route']) < (best[key]['depth'], best[key]['route']):
            best[key] = walk
    candidates = []
    for walk in best.values():
        candidates.extend(dict(walk, proof=row, kind='NODE', attachment=walk['node']) for row in proofs[('NODE', walk['node'])])
    for walk in walks:
        if walk['steps']:
            edge = walk['steps'][-1][1]
            candidates.extend(dict(walk, proof=row, kind='EDGE', attachment=edge) for row in proofs[('EDGE', edge)])
    picked = {}
    for candidate in candidates:
        key = candidate['seed'], candidate['proof']['chunk_id']
        rank = lambda row: (row['depth'], row['route'], row['kind'], row['proof']['evidence_id'])
        if key not in picked or rank(candidate) < rank(picked[key]):
            picked[key] = candidate
    return chunks, proofs, picked


def _verify(snapshot, result, expected_chunks, expected_paths=None):
    chunks = {row['chunk_id']: row for row in snapshot['chunks']}
    documents = {row['document_id']: row for row in snapshot['documents']}
    hits = result['hits']
    assert len(hits) == len(expected_chunks) and {row['chunk_id'] for row in hits} == set(expected_chunks), '문서 후보 집합 불일치'
    for row in hits:
        source = chunks[row['chunk_id']]
        assert row['body'] == source['body'] and row['locator'] == source['locator'], 'HIT 원문/줄 불일치'
        assert row['source_uri'] == documents[source['document_id']]['source_uri'], 'HIT 파일 불일치'
        assert row['document_score'] is not None, '검색 점수 누락'
    if expected_paths is None:
        assert not result['paths']
        return
    paths = [row for row in result['paths'] if row['record_type'] == 'PATH']
    assert len(paths) == len(expected_paths), '대표 경로 수 불일치'
    assert {(row['seed_id'], row['hit_chunk_id']) for row in paths} == set(expected_paths), '대표 경로 key 불일치'
    proof_map = defaultdict(list)
    for proof in snapshot['evidence']:
        proof_map[(proof['target_kind'], proof['target_id'])].append(proof)
    for row in paths:
        wanted = expected_paths[(row['seed_id'], row['hit_chunk_id'])]
        assert (row['step_no'], row['path_key'], row['to_id'], row['attachment_kind'], row['attachment_id'], row['quote']) == (
            wanted['depth'], wanted['route'], wanted['node'], wanted['kind'], wanted['attachment'], wanted['proof']['quote']), 'PATH 선택 불일치'
        same_path = [value for value in result['paths'] if value['seed_id'] == row['seed_id'] and
                     value['hit_chunk_id'] == row['hit_chunk_id'] and value['path_key'] == row['path_key']]
        steps = sorted((value for value in same_path if value['record_type'] == 'STEP'), key=lambda value: value['step_no'])
        assert len(steps) == len(wanted['steps']), 'STEP 수 불일치'
        for number, (step, actual) in enumerate(zip(wanted['steps'], steps), 1):
            assert actual['step_no'] == number
            assert tuple(actual[key] for key in ('from_id', 'edge_id', 'predicate_id', 'predicate_code', 'to_id', 'direction')) == step, 'STEP ID/방향 불일치'
        actual_proofs = Counter((value['step_no'], value['edge_id'], value['source_chunk_id'], value['quote'])
                               for value in same_path if value['record_type'] == 'EDGE_SOURCE')
        expected_proofs = Counter((number, step[1], proof['chunk_id'], proof['quote'])
                                 for number, step in enumerate(wanted['steps'], 1) for proof in proof_map[('EDGE', step[1])])
        assert actual_proofs == expected_proofs, '관계 원문 근거 불일치'
        for value in same_path:
            if value['record_type'] == 'EDGE_SOURCE':
                source = chunks[value['source_chunk_id']]
                assert value['body'] == source['body'] and value['quote'] in source['body']
                assert value['locator'] == source['locator']


def _reuse_existing_fixture(db, snapshot):
    expected = {key: len(snapshot[key]) for key in ('documents', 'chunks', 'nodes', 'edges', 'evidence')}
    current = db.status()
    marker = current.get('manifest') or {}
    digest = snapshot_hash(snapshot)
    if (not current.get('ready') or marker.get('state') != 'LOADED' or
        current.get('counts') != expected or marker.get('external_key') != digest):
        raise ValueError('재사용 대상의 LOADED manifest·snapshot SHA·건수가 다릅니다. DB를 변경하지 않습니다')
    return dict(status='verified_existing_fixture', snapshot_sha256=digest, counts=current['counts'])


def run(db, snapshot, output, initialize=True):
    """명시한 전용 DB에 실행한다. 자동 서버 관리·DROP·임의 벡터 생성은 하지 않는다."""
    if type(initialize) is not bool:
        raise ValueError('initialize는 boolean이어야 합니다')
    if snapshot.get('manifest', {}).get('role') != ROLE or not snapshot.get('smoke'):
        raise ValueError('native smoke 전용 fixture snapshot을 지정하세요')
    Database.__new__(Database)._validate_snapshot(snapshot)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    report = dict(role=ROLE, status='RUNNING', full_ontology_quality='NOT_EVALUATED',
                  human_reviewed=False, initialize=initialize,
                  graph_strategy=getattr(db, 'graph_strategy', 'shared'),
                  fixture_counts={key: len(snapshot[key]) for key in
                  ('documents', 'chunks', 'nodes', 'edges', 'evidence')}, stages=[])
    (output / 'snapshot.json').write_text(json.dumps(snapshot, ensure_ascii=False, indent=2))

    def save():
        (output / 'native-smoke.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str))

    def stage(name, function):
        item = dict(name=name, status='RUNNING')
        report['stages'].append(item)
        save()
        began = time.monotonic()
        try:
            item['result'] = function()
            item.update(status='PASS', seconds=time.monotonic() - began)
            save()
            return item['result']
        except BaseException as error:
            item.update(status='FAIL', error_type=type(error).__name__, error=str(error), seconds=time.monotonic() - began)
            report['status'] = 'FAIL'
            save()
            raise

    stage('doctor', db.doctor)
    if initialize:
        stage('init_explicit_private_namespace', db.init)
        stage('load', lambda: db.load(snapshot))
    else:
        stage('reuse_existing_fixture', lambda: _reuse_existing_fixture(db, snapshot))

    def identical():
        result = db.load(snapshot)
        assert result['status'] == 'unchanged'
        return result

    stage('load_identical_noop', identical)

    def current_status():
        result = db.status()
        assert result['ready'] and result['counts'] == report['fixture_counts']
        return result

    stage('status', current_status)
    identity = snapshot['manifest']['embedding']
    stage('model_digest', lambda: db.check_embedding(identity['model'], identity['digest']))
    question, vector = snapshot['smoke']['question'], snapshot['smoke']['query_vector']
    def discover():
        result = db.discover_seeds(question, vector, ['TAG DATA UPDATE'], policy='context')
        assert any(row['node_id'] == snapshot['smoke']['required_seed'] and row['match_method'] == 'EXACT_ALIAS' for row in result)
        return result

    seeds = stage('discover_exact_alias_and_hybrid', discover)
    chunks, proofs, picked = _expected(snapshot, seeds, 2)
    graph_ids = {row['proof']['chunk_id'] for row in picked.values()}
    report['oracle'] = dict(graph_chunks=sorted(graph_ids), direct_chunks=sorted(chunks), path_count=len(picked),
                            source='독립 Python snapshot 그래프; DB 재귀/검색 SQL을 사용하지 않음', ranking_quality='NOT_EVALUATED')
    for mode in ('graph', 'direct', 'hybrid'):
        def retrieve(mode=mode):
            result = db.search(question, vector, seeds=seeds, depth=2, top_k=5, mode=mode, policy='context')
            _verify(snapshot, result, chunks if mode == 'direct' else graph_ids,
                    None if mode == 'direct' else picked)
            if mode != 'direct':
                assert any(row.get('record_type') == 'STEP' and row.get('edge_id') == snapshot['smoke']['required_edge']
                           for row in result['paths']), 'SET 우변 제약 관계의 STEP가 없음'
            return result
        stage('search_' + mode, retrieve)
        for full in (False, True):
            def explain(mode=mode, full=full):
                plan = db.explain_search(question, vector, seeds=seeds, depth=2, top_k=5,
                                         mode=mode, policy='context', full=full)
                stem = mode + ('-full' if full else '-plain')
                (output / (stem + '.sql')).write_text('EXPLAIN ' + ('FULL ' if full else '') + plan['rendered_sql'])
                (output / (stem + '-parameterized.sql')).write_text(plan['sql'])
                (output / (stem + '-binds.json')).write_text(json.dumps(plan['parameters'], ensure_ascii=False, indent=2))
                (output / (stem + '-plan.txt')).write_text(plan['plan'])
                assert plan['plan'].strip(), '실행 계획이 비어 있음'
                if not full:
                    assert plan['operator_plan_present'], '연산자 트리 없이 스캔 여부를 판정할 수 없음'
                else:
                    assert 'SCAN_NODE_OPEN' in plan['plan'], '실제 실행 프로파일 누락'
                return plan
            stage('explain_' + mode + ('_full' if full else '_plain'), explain)
    def concept():
        result = db.concept(snapshot['smoke']['required_seed'])
        assert result['nodes'][0]['node_id'] == snapshot['smoke']['required_seed']
        assert len(result['edges']) == 2 and result['evidence']
        return result

    stage('concept_from_database', concept)
    report.update(status='PASS', native_scope='선별한 원문·실제 임베딩의 작은 SQL 통합 smoke; 전체 코퍼스/의미 품질/성능 합격 아님')
    save()
    return report


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', required=True, type=int)
    parser.add_argument('--user', default='SYS')
    parser.add_argument('--snapshot', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--reuse', action='store_true')
    parser.add_argument('--graph-strategy', choices=('shared', 'inline'), default='shared')
    parser.add_argument('--ollama', default='http://127.0.0.1:11434')
    parser.add_argument('--embed-model', default='bge-m3:latest')
    args = parser.parse_args(argv)
    if not 0 < args.port <= 65535:
        parser.error('--port는 1..65535여야 합니다')
    if args.reuse and args.snapshot is None:
        parser.error('--reuse에는 --snapshot이 필요합니다')
    return args


def main(argv=None):
    args = parse_args(argv)
    password = os.environ.get('GRAPH_RAG_PASSWORD')
    if not password:
        raise ValueError('GRAPH_RAG_PASSWORD 환경변수에 대상 DB 비밀번호를 지정하세요')
    if args.snapshot:
        data = json.loads(args.snapshot.read_text())
    else:
        from ollama_client import OllamaClient
        data = fixture(OllamaClient(args.ollama), args.embed_model)
    db = Database(args.host, args.port, args.user, password, graph_strategy=args.graph_strategy)
    try:
        result = run(db, data, args.output, initialize=not args.reuse)
        print(json.dumps({key: result[key] for key in ('status', 'role', 'initialize', 'graph_strategy',
                         'fixture_counts', 'native_scope')}, ensure_ascii=False, indent=2))
    finally:
        db.close()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('native smoke가 중단되었습니다. 서버 취소 완료를 의미하지 않습니다.', file=sys.stderr)
        raise SystemExit(130)
    except Exception as error:
        print('실패:', type(error).__name__, str(error), file=sys.stderr)
        raise SystemExit(1)
