"""정확 인용 무결성과 독립적인 사람의 의미 판정을 구분한다."""
import csv
import hashlib
import json
from pathlib import Path

POLICY = dict(eval_recall_min=.90, edge_precision_min=.95, edge_sample_size=100,
              critical_negative_required=1.0, required_alias_recall=1.0, wrong_merge_max=0)


def _ids(text):
    return [int(x.strip()) for x in str(text or '').replace(';', ',').split(',') if x.strip()]


def _csv(path):
    if not path.exists():
        return {}, []
    records, errors = {}, []
    with path.open(newline='', encoding='utf-8-sig') as stream:
        for row in csv.DictReader(stream):
            key = row.get('id', row.get('edge_id', ''))
            if not key or key in records:
                errors.append(dict(file=path.name, id=key, reason='빈 ID 또는 중복 판정'))
            records[key] = row
    return records, errors


def _template(path, fields, records):
    # 사람이 작성한 파일을 덮어쓰지 않는다. template은 별도 이름으로 갱신한다.
    with path.open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)


def verify(data, cache):
    cache = Path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    chunks = {r['chunk_id']: r for r in data['chunks']}
    nodes = {r['node_id']: r for r in data['nodes']}
    edges = {r['edge_id']: r for r in data['edges']}
    evidence = {r['evidence_id']: r for r in data['evidence']}
    failures = []
    if data.get('manifest', {}).get('complete') is False:
        failures.append(dict(reason='partial snapshot cannot pass integrity'))
    for name, key in (('documents', 'document_id'), ('chunks', 'chunk_id'), ('nodes', 'node_id'),
                      ('edges', 'edge_id'), ('evidence', 'evidence_id')):
        ids = [row.get(key) for row in data.get(name, [])]
        if len(ids) != len(set(ids)) or any(type(i) is not int or not 0 < i <= 2**63-1 for i in ids):
            failures.append(dict(table=name, reason='duplicate or invalid INT64 IDs'))
    valid_evidence = set()
    for ev in evidence.values():
        chunk = chunks.get(ev['chunk_id'])
        targets = nodes if ev['target_kind'] == 'NODE' else edges if ev['target_kind'] == 'EDGE' else {}
        if ev['target_id'] not in targets or not chunk or not ev.get('quote') or ev['quote'] not in chunk['body']:
            failures.append(dict(evidence_id=ev['evidence_id'], reason='invalid reference or quotation'))
        else:
            valid_evidence.add(ev['evidence_id'])
    for edge in edges.values():
        if edge.get('state') != 'APPROVED':
            continue
        if any(edge.get(k) not in nodes for k in ('source_id', 'target_id', 'predicate_id')):
            failures.append(dict(edge_id=edge['edge_id'], reason='dangling approved edge'))
            continue
        predicate = nodes[edge['predicate_id']]
        if predicate.get('node_kind') != 'RELATION_TYPE' or any(
                predicate.get(field) and predicate[field] != nodes[edge[key]].get('node_kind')
                for field, key in (('source_kind', 'source_id'), ('target_kind', 'target_id'))):
            failures.append(dict(edge_id=edge['edge_id'], reason='relation type/domain mismatch'))
        if not any(e['target_kind'] == 'EDGE' and e['target_id'] == edge['edge_id'] and e['evidence_id'] in valid_evidence
                   for e in evidence.values()):
            failures.append(dict(edge_id=edge['edge_id'], reason='approved edge has no exact evidence'))
    entities = [n for n in nodes.values() if n.get('node_kind') == 'ENTITY']
    if edges and not entities:
        failures.append(dict(reason='knowledge graph contains no ENTITY; all-CLASS extraction is invalid'))
    gold = json.loads(Path(__file__).with_name('gold.json').read_text(encoding='utf-8'))
    items = gold['items']
    critical_files = {s['source_path'] for i in items if i['critical_negative'] for s in i['sources']}
    approved = {i: e for i, e in edges.items() if e.get('state') == 'APPROVED'}
    sample = set(sorted(approved, key=lambda i: hashlib.sha256(str(i).encode()).hexdigest())[:POLICY['edge_sample_size']])
    critical_edges = {ev['target_id'] for ev in evidence.values() if ev['target_kind'] == 'EDGE'
                      and ev['target_id'] in approved and chunks.get(ev['chunk_id'], {}).get('source_path') in critical_files}
    required_edges = sample | critical_edges
    candidates = []
    for item in items:
        # 검토 편의용 후보만 제시하며 의미 판정은 바꾸지 않는다.
        keys = item.get('expected_keys', [])
        ids = [n['node_id'] for n in nodes.values() if any(k.casefold() in str(n.get('label', '')).casefold() for k in keys)]
        candidates.append(dict(id=item['id'], candidate_nodes=ids, semantic_verdict='NOT_REVIEWED'))
    _template(cache/'semantic-review-template.csv', ['id', 'split', 'question', 'claim', 'conditions', 'critical_negative',
              'forbidden_claims', 'expected_keys', 'sources', 'verdict', 'edge_ids', 'evidence_ids', 'reviewer', 'notes'],
              [dict(i, conditions=json.dumps(i['conditions'], ensure_ascii=False),
                    expected_keys=json.dumps(i['expected_keys'], ensure_ascii=False),
                    forbidden_claims=json.dumps(i['forbidden_claims'], ensure_ascii=False),
                    sources=json.dumps(i['sources'], ensure_ascii=False)) for i in items])
    _template(cache/'edge-review-template.csv', ['edge_id', 'sample_required', 'critical_source', 'source_id', 'predicate_id',
              'target_id', 'evidence_ids', 'verdict', 'reviewer', 'notes'],
              [dict(e, sample_required=i in required_edges, critical_source=i in critical_edges,
                    evidence_ids=','.join(str(ev['evidence_id']) for ev in evidence.values()
                                          if ev['target_kind'] == 'EDGE' and ev['target_id'] == i))
               for i, e in sorted(approved.items())])
    alias_groups = {}
    for n in nodes.values():
        if n.get('node_kind') == 'ALIAS':
            alias_groups.setdefault(n.get('canonical_id'), []).append(n['node_id'])
    alias_tasks = [dict(i, required=True) for i in gold.get('required_aliases', [])]
    alias_tasks += [dict(id='MERGE:'+str(cid), required=False, canonical_id=cid, alias_node_ids=','.join(map(str, ids)),
                        aliases=[nodes[n]['label'] for n in ids]) for cid, ids in sorted(alias_groups.items(), key=lambda p: str(p[0]))]
    _template(cache/'alias-review-template.csv', ['id', 'required', 'expected_keys', 'aliases', 'canonical_id', 'alias_node_ids',
              'evidence_ids', 'verdict', 'merge_verdict', 'reviewer', 'notes'],
              [dict(i, aliases=json.dumps(i.get('aliases', []), ensure_ascii=False),
                    expected_keys=json.dumps(i.get('expected_keys', []), ensure_ascii=False)) for i in alias_tasks])
    gold_review, errors = _csv(cache/'semantic-review.csv')
    edge_review, other = _csv(cache/'edge-review.csv'); errors += other
    alias_review, other = _csv(cache/'alias-review.csv'); errors += other

    def adjudicated(row):
        return row and row.get('verdict') in ('PASS', 'FAIL') and bool(row.get('reviewer', '').strip()) and bool(row.get('notes', '').strip())

    def refs(row, edge_ids=None):
        try:
            ids = _ids(row.get('evidence_ids'))
            return bool(ids) and all(i in valid_evidence for i in ids) and (edge_ids is None or
                all(any(evidence[i]['target_kind'] == 'EDGE' and evidence[i]['target_id'] == edge for i in ids) for edge in edge_ids))
        except (ValueError, TypeError):
            return False

    judged_gold = {}
    for item in items:
        row = gold_review.get(item['id'])
        if not adjudicated(row):
            continue
        if row['verdict'] == 'PASS':
            try:
                claimed = _ids(row.get('edge_ids'))
                okay = claimed and all(e in approved for e in claimed) and refs(row, claimed)
                # 위치 대조는 attribution guard다. 같은 명제인지는 reviewer/notes가 판정한다.
                source_paths = {s['source_path'] for s in item['sources']}
                quoted = any(chunks[evidence[i]['chunk_id']].get('source_path') in source_paths and
                             any(s['quote'] in chunks[evidence[i]['chunk_id']]['body'] for s in item['sources'])
                             for i in _ids(row.get('evidence_ids')) if i in valid_evidence)
                if not okay or not quoted:
                    errors.append(dict(id=item['id'], reason='PASS requires approved edge/exact evidence/gold source references'))
                    continue
            except (ValueError, KeyError, TypeError):
                errors.append(dict(id=item['id'], reason='invalid PASS reference IDs'))
                continue
        judged_gold[item['id']] = row['verdict']
    judged_edges = {}
    for i in required_edges:
        row = edge_review.get(str(i))
        if not adjudicated(row):
            continue
        if not refs(row, [i]):
            errors.append(dict(edge_id=i, reason='edge adjudication needs exact evidence of that edge'))
            continue
        judged_edges[i] = row['verdict']
    judged_aliases, wrong_merges = {}, []
    for task in alias_tasks:
        row = alias_review.get(task['id'])
        if not adjudicated(row) or row.get('merge_verdict') not in ('PASS', 'FAIL'):
            continue
        if row.get('merge_verdict') == 'FAIL':
            wrong_merges.append(task['id'])
        if row['verdict'] == 'PASS':
            try:
                cid, aids = int(row.get('canonical_id', '')), _ids(row.get('alias_node_ids'))
                okay = cid in nodes and nodes[cid].get('node_kind') in ('ENTITY', 'CLASS') and aids and all(
                    a in nodes and nodes[a].get('node_kind') == 'ALIAS' and nodes[a].get('canonical_id') == cid for a in aids)
                if not task['required']:
                    okay = okay and cid == task['canonical_id'] and set(aids) == set(alias_groups[cid])
                else:
                    normalize = lambda v: ' '.join(str(v).casefold().split())
                    labels = {normalize(nodes[a]['label']) for a in aids} | {normalize(nodes[cid]['label'])}
                    okay = okay and all(normalize(a) in labels for a in task['aliases'])
                linked = refs(row) and all(evidence[i]['target_kind'] == 'NODE' and
                                           evidence[i]['target_id'] in set(aids) | {cid}
                                           for i in _ids(row.get('evidence_ids')))
                if not okay or not linked:
                    errors.append(dict(id=task['id'], reason='alias PASS requires canonical/alias/evidence references'))
                    continue
            except (ValueError, TypeError, KeyError):
                errors.append(dict(id=task['id'], reason='invalid alias reference IDs'))
                continue
        judged_aliases[task['id']] = row['verdict']
    eval_ids = [i['id'] for i in items if i['split'] == 'eval']
    critical_ids = [i['id'] for i in items if i['critical_negative']]
    required_alias_ids = [i['id'] for i in alias_tasks if i['required']]
    pending = [i['id'] for i in items if i['id'] not in judged_gold]
    pending_edges = sorted(required_edges - judged_edges.keys())
    pending_aliases = [i['id'] for i in alias_tasks if i['id'] not in judged_aliases]
    recall = sum(judged_gold.get(i) == 'PASS' for i in eval_ids) / len(eval_ids) if eval_ids else 0
    precision = sum(v == 'PASS' for v in judged_edges.values()) / len(judged_edges) if judged_edges else None
    alias_recall = sum(judged_aliases.get(i) == 'PASS' for i in required_alias_ids) / len(required_alias_ids) if required_alias_ids else 0
    gates = dict(snapshot_complete=data.get('manifest',{}).get('complete') is not False, all_gold_reviewed=not pending, all_sample_edges_reviewed=bool(required_edges) and not pending_edges,
                 edge_precision=precision is not None and precision >= POLICY['edge_precision_min'],
                 eval_recall=len(eval_ids) == 40 and recall >= POLICY['eval_recall_min'],
                 critical_negative=bool(critical_ids) and all(judged_gold.get(i) == 'PASS' for i in critical_ids),
                 required_aliases=bool(required_alias_ids) and alias_recall == 1,
                 all_alias_merges_reviewed=not pending_aliases, wrong_merges=not wrong_merges,
                 valid_review_records=not errors)
    complete = not (pending or pending_edges or pending_aliases)
    quality = 'PASS' if complete and all(gates.values()) and not failures else 'FAIL' if complete else 'PARTIAL' if (judged_gold or judged_edges or judged_aliases) else 'NOT_REVIEWED'
    result = dict(integrity='PASS' if not failures else 'FAIL', failures=failures, semantic_quality=quality,
                  quality_policy=POLICY, gates=gates, gold_count=len(items), pending=pending,
                  pending_edges=pending_edges, pending_aliases=pending_aliases, review_errors=errors,
                  eval_recall=recall, edge_precision=precision, edge_adjudicated=len(judged_edges),
                  edge_sample_size=len(sample), edge_required_count=len(required_edges),
                  required_alias_recall=alias_recall, wrong_merges=wrong_merges, candidates=candidates,
                  db_integration='NOT_RUN', performance='NOT_RUN')
    (cache/'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return result
