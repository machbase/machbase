"""게시 전 의미 그래프 계약. 모델 판정만으로 형식/범위 위반을 허용하지 않는다."""
import collections
import json
from semantic_builder import complete,PREDICATES
from ontology import normalize


def verify(data):
    nodes={n['node_id']:n for n in data['nodes']};chunks={c['chunk_id']:c for c in data['chunks']}
    units={u['unit_id']:u for u in data.get('source_units',[])}
    proofs=collections.defaultdict(list)
    errors=[]
    for evidence in data['evidence']:
        chunk=chunks.get(evidence['chunk_id'])
        if not chunk or evidence['quote'] not in chunk['body']:errors.append('원문 근거 불일치 '+str(evidence['evidence_id']))
        proofs[(evidence['target_kind'],evidence['target_id'])].append(evidence)
    degree=collections.Counter();predicates=collections.Counter()
    for edge in data['edges']:
        if edge['state']!='APPROVED':continue
        pred=nodes[edge['predicate_id']]['code']
        if pred=='INSTANCE_OF':continue
        predicates[pred]+=1
        if pred not in PREDICATES:errors.append('비의미 술어 게시 '+pred)
        for nid in (edge['source_id'],edge['target_id']):
            degree[nid]+=1
            if not proofs[('NODE',nid)]:errors.append('노드 근거 누락 '+str(nid))
        try:
            scope=json.loads(edge['scope_json']);unit=units[scope['primary_unit']]
            if not complete(unit) or scope['assertion']!=unit['quote']:raise ValueError('완전 명제와 scope 불일치')
            if not any(p['chunk_id']==unit['chunk_id'] and p['quote']==unit['quote'] for p in proofs[('EDGE',edge['edge_id'])]):raise ValueError('주 명제 edge 근거 누락')
            for condition in scope['conditions']:
                original=units[condition['unit_id']]
                if condition['text']!=original['quote'] or not any(p['chunk_id']==original['chunk_id'] and p['quote']==original['quote'] for p in proofs[('EDGE',edge['edge_id'])]):raise ValueError('조건 근거 누락')
        except (KeyError,ValueError,TypeError) as error:errors.append('scope 검증 실패 '+str(edge['edge_id'])+': '+str(error))
    for node in nodes.values():
        if node['node_kind']=='ENTITY' and node['state']=='PUBLISHED':
            if node['label'].startswith('Rule '):errors.append('원문 Rule 노드 게시')
            if not degree[node['node_id']]:errors.append('승인 의미 관계가 없는 게시 노드 '+node['label'])
        if node['node_kind']=='ALIAS' and normalize(node['label'])==normalize(nodes[node['canonical_id']]['label']):errors.append('자기 이름 별칭 '+node['label'])
    if not predicates:errors.append('게시 가능한 의미 관계가 없음')
    return dict(status='PASS' if not errors else 'FAIL',errors=errors,predicates=dict(predicates),
        published_entities=sum(n['node_kind']=='ENTITY' and n['state']=='PUBLISHED' for n in nodes.values()),
        published_semantic_edges=sum(predicates.values()),human_reviewed=False)
