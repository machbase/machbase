"""문장을 임의 길이로 자르지 않는 원문 block과 검색 청크."""
import hashlib
from pathlib import Path
import re
from corpus import stable_id, utf8_prefix, embedding_text

VERSION='complete-blocks-v1'


def collect(source):
    source=Path(source).resolve(strict=True)
    paths=sorted(source.rglob('*.md')) if source.is_dir() else [source]
    documents,chunks,units,files=[],[],[],[]
    for path in paths:
        relative=path.relative_to(source).as_posix() if source.is_dir() else path.name
        raw=path.read_bytes();lines=raw.decode('utf-8').splitlines(keepends=True)
        sha=hashlib.sha256(raw).hexdigest();first=0;title=path.stem
        if lines and lines[0].strip()=='---':
            end=next((i for i in range(1,len(lines)) if lines[i].strip()=='---'),None)
            if end is not None:
                for line in lines[1:end]:
                    match=re.match(r'title:\s*(.*)',line)
                    if match:title=match[1].strip().strip("'\"")
                first=end+1
        did=stable_id('document',relative)
        documents.append(dict(document_id=did,kb_id=1,title=utf8_prefix(title,256),source_uri='file:'+relative,
                              current_version=1,state='PUBLISHED',external_key=relative,source_sha256=sha))
        blocks=[];headings=[];table_header='';i=first
        while i<len(lines):
            text=lines[i];clean=text.strip()
            heading=re.match(r'^(#{1,6})\s+(.+)',clean)
            if heading:
                level=len(heading[1]);headings=[h for h in headings if h[0]<level]+[(level,heading[2])]
                i+=1;table_header='';continue
            if not clean or re.fullmatch(r'<a\s+[^>]*>\s*</a>',clean,re.I) or clean.startswith(('{{<','{{%')):
                i+=1;continue
            start=i
            if clean.startswith(('```','~~~')):
                fence=clean[:3];i+=1
                while i<len(lines) and not lines[i].lstrip().startswith(fence):i+=1
                if i<len(lines):i+=1
                kind='example'
            elif clean.startswith('|'):
                if i+1<len(lines) and re.fullmatch(r'[|:\-\s]+',lines[i+1]):
                    table_header=clean;i+=2;continue
                if re.fullmatch(r'[|:\-\s]+',clean):i+=1;continue
                i+=1;kind='table_row'
            else:
                i+=1;kind='prose';table_header=''
                while i<len(lines) and lines[i].strip() and not re.match(r'\s*(?:#{1,6}\s|```|~~~|<a\s|\{\{[<%]|\|)',lines[i]):i+=1
            quote=''.join(lines[start:i]);heading_text=' > '.join([title]+[h[1] for h in headings])
            uid='U'+str(stable_id('unit',relative+':'+str(start+1)+':'+sha))
            unit=dict(unit_id=uid,source_path=relative,source_sha256=sha,document_id=did,line_start=start+1,line_end=i,
                      quote=quote,heading=heading_text,kind=kind,table_header=table_header)
            blocks.append(unit);units.append(unit)
        # 같은 heading의 완전한 block을 묶고 긴 block도 자르지 않는다.
        groups=[];current=[];size=0
        for block in blocks:
            if current and (size+len(block['quote'])>1400 or block['heading']!=current[0]['heading']):
                groups.append(current);current=[];size=0
            current.append(block);size+=len(block['quote'])
        if current:groups.append(current)
        for ordinal,group in enumerate(groups,1):
            lo,hi=group[0]['line_start'],group[-1]['line_end'];body=''.join(lines[lo-1:hi]);body_sha=hashlib.sha256(body.encode()).hexdigest()
            cid=stable_id('semantic-chunk',relative+':'+str(lo)+':'+body_sha)
            chunks.append(dict(chunk_id=cid,kb_id=1,document_id=did,document_version=1,ordinal=ordinal,
                locator=relative+':L'+str(lo)+'-L'+str(hi),body=body,embedding=None,analysis_state='PENDING',
                extractor_version=None,fact_count=None,source_path=relative,line_start=lo,line_end=hi,
                source_sha256=sha,heading=group[0]['heading'],body_sha256=body_sha,embedding_text=embedding_text(body),
                embedding_text_sha256=hashlib.sha256(embedding_text(body).encode()).hexdigest()))
            for unit in group:unit['chunk_id']=cid
        files.append(dict(path=relative,sha256=sha,bytes=len(raw),lines=len(lines),chunks=len(groups)))
    return dict(documents=documents,chunks=chunks,units=units,issues=[],manifest=dict(chunk_version=VERSION,files=files))
