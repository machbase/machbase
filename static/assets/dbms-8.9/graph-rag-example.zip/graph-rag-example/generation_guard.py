"""관측된 SQL 예제 창작과 약한 원문 양태의 강화에 대한 출력 검사."""
import re
from db import split_sql


def canonical(sql):
    # 따옴표 안의 값은 보존하고 바깥의 공백만 정규화한다.
    tokens=re.findall(r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|[^\s'\"]+",sql)
    return ' '.join(tokens)


def blocks(text):
    return [body for language,body in re.findall(r'```([^\n`]*)\n(.*?)```',text,re.S)
            if language.strip().casefold()=='sql' or re.match(r'\s*(?:SELECT|WITH|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|SHOW)\b',body,re.I)]


def check(text,evidence,question):
    originals={canonical(statement) for block in blocks(evidence) for statement in split_sql(block)}
    for block in blocks(text):
        for statement in split_sql(block):
            if canonical(statement) not in originals:
                return 'SQL 예제는 원문 코드 블록의 완전한 문장을 그대로 사용해야 합니다. 테이블명, 컬럼명, 값, JSON 경로를 임의로 만들지 마세요.'
    if '롤백' in question and '가정하지' in evidence:
        if re.search(r'롤백(?:되지는|되지|하지|은\s*되지)\s*않|이미\s*적용.{0,35}(?:유지|남)',text):
            return '원문은 원자적 롤백을 보장하지 않는다는 뜻입니다. 절대 롤백하지 않는다거나 이미 적용된 변경이 반드시 유지된다고 단정하지 말고 보장 여부만 답하세요.'
    if re.search(r'Edition|에디션',question,re.I) and '참조' in evidence:
        if re.search(r'(?:기존|SET\s+value).{0,150}Standard.{0,35}지원(?:됩니다|합니다|한다)',text,re.S):
            return 'TAG DATA UPDATE 자체의 Edition과 금지된 SET 기존 값 참조를 구분하세요. Standard Edition이 기존 값 참조까지 지원한다고 쓰지 마세요.'
    return None
