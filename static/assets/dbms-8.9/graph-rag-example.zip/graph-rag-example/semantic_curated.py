"""검토된 source relation 명세에서 게시용 온톨로지를 재현한다."""
import hashlib
import json
import math
from pathlib import Path
from corpus import stable_id
from ontology import atomic_json,cached
from semantic_corpus import collect
from semantic_catalog import catalog
from semantic_builder import make_snapshot,structural_reason,complete,digest
from semantic_gate import verify
from ollama_client import OllamaClient

VERSION='source-reviewed-ontology-v1'


def resolve(reference,units):
    found=[u for u in units if u['source_path']==reference['path'] and u['line_start']<=reference['line']<=u['line_end']]
    if len(found)!=1:raise ValueError('원문 reference 범위 오류: '+str(reference))
    unit=found[0]
    if not complete(unit):raise ValueError('완결되지 않은 원문 reference: '+str(reference))
    return unit


def prepare(source,cache,spec_path,url,embed_model):
    data=collect(source);cache=Path(cache);spec=json.loads(Path(spec_path).read_text());concepts=catalog(data['units'])
    file_sha={f['path']:f['sha256'] for f in data['manifest']['files']}
    if spec.get('source_manifest')!=file_sha:raise ValueError('검토 명세와 원문 SHA가 다릅니다. 재검토가 필요합니다')
    claims=[];reviews={};provenance=[]
    for index,item in enumerate(spec['assertions'],1):
        primary=resolve(item['source'],data['units'])
        if item.get('source_quote')!=primary['quote']:raise ValueError('검토 원문 단위가 바뀌었습니다: '+str(index))
        conditions=[resolve(ref,data['units']) for ref in item.get('conditions',[])]
        claim=dict(unit=primary['unit_id'],subject=item['subject'],predicate=item['predicate'],object=item.get('object','CONSTRAINT'),
                   constraint_name=item.get('constraint_name',''),conditions=[u['unit_id'] for u in conditions])
        reason=structural_reason(claim,concepts,{u['unit_id']:u for u in data['units']})
        if reason:raise ValueError('명세 '+str(index)+' 안전 검사 실패: '+reason)
        if item.get('reviewer')!='Codex source review' or not item.get('rationale'):raise ValueError('검토자/판정 근거 누락')
        key=digest(claim);claims.append(claim);reviews[key]=dict(supported=True,verdict='SOURCE_REVIEWED',reviewer=item['reviewer'],reason=item['rationale'],
            support_units=[primary['unit_id']]+[u['unit_id'] for u in conditions])
        provenance.append(dict(index=index,claim_key=key,source=item['source'],rationale=item['rationale']))
    result=make_snapshot(data,concepts,claims,reviews)
    edge_map={e['edge_id']:e for e in result['edges']}
    existing={e['evidence_id'] for e in result['evidence']}
    for item,claim in zip(spec['assertions'],claims):
        edge=edge_map[stable_id('semantic-edge',digest(claim))]
        parallel=[]
        for reference in item.get('corroborating',[]):
            unit=resolve(reference,data['units'])
            if unit['quote']!=reference['quote'] or not item.get('parallel_review'):
                raise ValueError('대조 검토 원문/기록 불일치')
            parallel.append(dict(unit_id=unit['unit_id'],text=unit['quote']))
            for kind,target in [('EDGE',edge['edge_id']),('NODE',edge['source_id']),('NODE',edge['target_id'])]:
                eid=stable_id('semantic-proof',kind+':'+str(target)+':'+unit['unit_id'])
                if eid not in existing:
                    result['evidence'].append(dict(evidence_id=eid,kb_id=1,target_kind=kind,target_id=target,chunk_id=unit['chunk_id'],quote=unit['quote']))
                    existing.add(eid)
        scope=json.loads(edge['scope_json']);scope['parallel_sources']=parallel;edge['scope_json']=json.dumps(scope,ensure_ascii=False,separators=(',',':'))
    result['manifest']['counts']['evidence']=len(result['evidence'])
    node_map={n['node_id']:n for n in result['nodes']}
    for node in result['nodes']:
        if node['node_kind']!='ENTITY' or node.get('category')=='Constraint':continue
        summaries=[]
        for edge in result['edges']:
            if edge['predicate_text']=='INSTANCE_OF':continue
            if edge['source_id']==node['node_id']:
                summaries.append(edge['predicate_text']+': '+node_map[edge['target_id']]['label'])
        text=node['label']+' ('+node['category']+')'
        for summary in list(dict.fromkeys(summaries)):
            if len((text+'\n'+summary).encode())<=2048:text+='\n'+summary
        node['description']=text
    gate=verify(result)
    if gate['status']!='PASS':raise ValueError('게시 계약 실패: '+json.dumps(gate,ensure_ascii=False))
    client=OllamaClient(url);models=client.models();model_digest=models[embed_model]
    result['manifest'].update(schema_version=2,complete=True,ontology_scope=dict(product='Machbase',version='8.7.0',basis='provided TAG manual'),
        extractor=dict(name='semantic',version=VERSION,mode='source-reviewed specification'),
        embedding=dict(model=embed_model,digest=model_digest,dimensions=1024,normalization='L2'),
        semantic_validation=dict(complete=True,model='Codex source review',digest=hashlib.sha256(Path(spec_path).read_bytes()).hexdigest(),validator_version=VERSION,
            agent_reviewed=True,human_reviewed=False),publication_gate=gate)
    result['source_review']=provenance
    atomic_json(cache/'snapshot.unembedded.json',result);atomic_json(cache/'publication-gate.json',gate)
    def embed(text):
        vector=cached(cache,'embeddings',dict(model=model_digest,text=text),lambda:client.embed(embed_model,text))
        if len(vector)!=1024:raise ValueError('1024D 임베딩 필요')
        norm=math.sqrt(sum(float(v)**2 for v in vector))
        if not math.isfinite(norm) or norm<=0:raise ValueError('임베딩 norm 오류')
        return [float(v)/norm for v in vector]
    for i,chunk in enumerate(result['chunks'],1):
        chunk['embedding']=embed(chunk['embedding_text'])
        if i%25==0:
            atomic_json(cache/'progress.json',dict(stage='EMBED_CHUNKS',processed=i,total=len(result['chunks'])))
            print('semantic chunks',i,'/',len(result['chunks']),flush=True)
    nodes={n['node_id']:n for n in result['nodes']};neighbors={nid:[] for nid in nodes}
    for edge in result['edges']:
        if edge['predicate_text']!='INSTANCE_OF':neighbors[edge['source_id']].append(edge['predicate_text']+' '+nodes[edge['target_id']]['label'])
    entities=[n for n in nodes.values() if n['node_kind'] in ('ENTITY','CLASS')]
    for i,node in enumerate(entities,1):
        node['search_text']='\n'.join([node['label'],node.get('description') or '']+neighbors[node['node_id']][:6]);node['embedding']=embed(node['search_text'])
        if i%20==0:print('semantic nodes',i,'/',len(entities),flush=True)
    atomic_json(cache/'snapshot.json',result);atomic_json(cache/'progress.json',dict(stage='READY_FOR_PUBLICATION',counts=result['manifest']['counts'],human_reviewed=False))
    return result
