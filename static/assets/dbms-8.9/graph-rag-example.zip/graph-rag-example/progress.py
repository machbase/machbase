"""질의 단계의 시작·종료·실패 시간과 총 경과 시간을 표시한다."""
from contextlib import contextmanager
from datetime import datetime
import time
import threading


class Progress:
    def __init__(self,emit=print):
        self.emit=emit
        self.started=time.monotonic()
        self.stages=[]

    def skip(self,name):
        self.stages.append(dict(stage=name,status='SKIPPED',seconds=0))
        self.emit(f'[{datetime.now():%H:%M:%S}] {name} 생략')

    @contextmanager
    def stage(self,name):
        began=time.monotonic()
        self.emit(f'[{datetime.now():%H:%M:%S}] {name} 시작')
        record=dict(stage=name,status='RUNNING')
        self.stages.append(record)
        stopped=threading.Event()
        def heartbeat():
            while not stopped.wait(5):
                self.emit(f'[{datetime.now():%H:%M:%S}] {name} 진행 중 · {time.monotonic()-began:.1f}초 · 누적 {time.monotonic()-self.started:.1f}초')
        worker=threading.Thread(target=heartbeat,daemon=True)
        worker.start()
        try:
            yield
        except BaseException:
            stopped.set();worker.join()
            record.update(status='FAILED',seconds=time.monotonic()-began)
            self.emit(f'[{datetime.now():%H:%M:%S}] {name} 중단 · {record["seconds"]:.3f}초 · 누적 {time.monotonic()-self.started:.3f}초')
            raise
        else:
            stopped.set();worker.join()
            record.update(status='DONE',seconds=time.monotonic()-began)
            self.emit(f'[{datetime.now():%H:%M:%S}] {name} 완료 · {record["seconds"]:.3f}초 · 누적 {time.monotonic()-self.started:.3f}초')

    def finish(self):
        elapsed=time.monotonic()-self.started
        self.emit(f'전체 처리 시간: {elapsed:.3f}초')
        return dict(stages=list(self.stages),total_seconds=elapsed)
