"""Packaged example resources and cache paths."""
import os
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = Path.cwd()
DEFAULT_CACHE = Path(os.environ.get('GRAPH_RAG_CACHE', ROOT/'graph-rag-cache'))
