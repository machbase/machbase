"""명시적으로 지정한 Machbase에만 연결하는 GraphRAG SQL 어댑터."""
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import time
import unicodedata

from paths import ROOT
from shared_query import build_shared_query

HERE = Path(__file__).resolve().parent
SQL = HERE / "sql"
DIMENSIONS = 1024
MAX_ID = (1 << 63) - 1
MANIFEST_ID = MAX_ID
PREFIX = "GRRAG_"
TABLES = {
    "documents": ("DOCUMENT", "document_id", ("document_id", "kb_id", "title", "source_uri", "current_version", "state", "external_key")),
    "chunks": ("CHUNK", "chunk_id", ("chunk_id", "kb_id", "document_id", "document_version", "ordinal", "locator", "body", "embedding", "analysis_state", "extractor_version", "fact_count")),
    "nodes": ("NODE", "node_id", ("node_id", "kb_id", "node_kind", "label", "code", "description", "search_text", "state", "embedding", "canonical_id", "label_key", "source_kind", "target_kind")),
    "edges": ("EDGE", "edge_id", ("edge_id", "kb_id", "source_id", "predicate_id", "target_id", "state", "subject_text", "predicate_text", "object_text", "extractor_version", "canonical_edge_id", "scope_json")),
    "evidence": ("EVIDENCE", "evidence_id", ("evidence_id", "kb_id", "target_kind", "target_id", "chunk_id", "quote")),
}
RELATIONS = {"INSTANCE_OF", "SUBCLASS_OF", "PART_OF", "REQUIRES", "APPLIES_TO", "SUPPORTS", "LIMITED_BY", "RELATED_TO"}
NODE_KINDS = {"CLASS", "ENTITY", "SYMPTOM", "FAILURE", "PROCEDURE", "ALIAS", "RELATION_TYPE"}
WIDTHS = {
    "documents": {"title": 256, "source_uri": 1024, "state": 16, "external_key": 256},
    "chunks": {"locator": 256, "analysis_state": 16, "extractor_version": 128},
    "nodes": {"node_kind": 16, "label": 256, "code": 64, "description": 2048, "state": 16, "label_key": 256, "source_kind": 16, "target_kind": 16},
    "edges": {"state": 16, "subject_text": 256, "predicate_text": 128, "object_text": 256, "extractor_version": 128},
    "evidence": {"target_kind": 8, "quote": 2048},
}


def _connect(**kwargs):

    from machbaseAPI import connect
    return connect(**kwargs)


def split_sql(text):
    """문자열 안의 세미콜론과 SQL 주석을 구분한다."""
    statements, chars, quote = [], [], None
    index = 0
    while index < len(text):
        ch = text[index]
        if quote:
            chars.append(ch)
            if ch == quote:
                if index + 1 < len(text) and text[index + 1] == quote:
                    chars.append(ch)
                    index += 1
                else:
                    quote = None
        elif ch in ("'", '"'):
            quote = ch
            chars.append(ch)
        elif text[index:index + 2] == "--":
            end = text.find("\n", index)
            index = len(text) if end < 0 else end
            chars.append("\n")
            continue
        elif ch == ";":
            if "".join(chars).strip():
                statements.append("".join(chars).strip())
            chars = []
        else:
            chars.append(ch)
        index += 1
    if quote:
        raise ValueError("닫히지 않은 SQL 문자열입니다")
    if "".join(chars).strip():
        statements.append("".join(chars).strip())
    return statements


def _id(value, name="ID"):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 < value < MAX_ID:
        raise ValueError(name + "는 예약값을 제외한 양수 LONG이어야 합니다")
    return value


def _vector(value):
    if not isinstance(value, (list, tuple)) or len(value) != DIMENSIONS:
        raise ValueError("임베딩은 1024차원이어야 합니다")
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in value):
        raise ValueError("임베딩에는 유한 숫자만 허용합니다")
    norm = math.sqrt(sum(float(x) * float(x) for x in value))
    if not math.isfinite(norm) or norm == 0:
        raise ValueError("임베딩은 0이 아닌 유한 벡터여야 합니다")
    return [float(x) / norm for x in value]


def snapshot_hash(snapshot):
    return hashlib.sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _semantic_validation(value):
    if not isinstance(value, dict) or value.get("complete") is not True:
        raise ValueError("의미 검증이 완료된 validated snapshot만 적재할 수 있습니다")
    for key in ("model", "digest", "validator_version"):
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise ValueError("의미 검증 manifest에 model/digest/validator_version이 필요합니다")
    if not isinstance(value.get("human_reviewed", False), bool):
        raise ValueError("human_reviewed는 boolean이어야 합니다")
    # 모델 검증 완료와 사람 검토 여부는 별개이며 품질 합격을 자동 판정하지 않는다.
    return {key: value[key] for key in ("complete", "model", "digest", "validator_version")} | {
        "human_reviewed": value.get("human_reviewed", False)}


def render_sql(sql, params):
    """EXPLAIN 전용 literal 출력. 일반 실행은 항상 named bind를 사용한다."""
    def literal(value):
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float) and math.isfinite(value):
            return repr(value)
        if isinstance(value, str):
            if "\x00" in value:
                raise ValueError("EXPLAIN literal에는 NUL을 사용할 수 없습니다")
            return "'" + value.replace("'", "''") + "'"
        raise ValueError("지원하지 않는 EXPLAIN 매개변수입니다")
    tokens = re.compile(r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|--[^\n]*|:([A-Za-z_]\w*)")
    return tokens.sub(lambda match: literal(params[match[1]]) if match[1] else match[0], sql)


class Database:
    def __init__(self, host, port, user, password, graph_strategy="shared"):
        if not host or not user or not password or isinstance(port, bool) or not 0 < int(port) <= 65535:
            raise ValueError("host/port/user/password 연결 옵션을 확인하세요")
        if graph_strategy not in ("shared", "inline"):
            raise ValueError("graph_strategy는 shared/inline이어야 합니다")
        self.target = dict(host=host, port=int(port), user=user)
        self.graph_strategy = graph_strategy
        self.embedding_identity = None
        self.connection = None

        # 비밀번호는 공개 target/status가 아닌 연결 생성 클로저 안에만 보관한다.
        def open_connection():
            try:
                return _connect(host=host, port=int(port), user=user, password=password,
                                query_timeout=180, client_id="GRRAG_DEMO")
            except Exception:
                raise RuntimeError("지정한 Machbase에 연결하지 못했습니다. 연결 옵션과 서버 상태를 확인하세요") from None

        self._open_connection = open_connection
        self.connection = self._open_connection()

    def close(self):
        connection, self.connection = self.connection, None
        if connection is not None:
            connection.close()

    def reconnect(self):
        """중단된 프로토콜 연결을 재사용하지 않는다. 서버 쿼리 취소 확인 API는 아니다."""
        previous, self.connection = self.connection, None
        self.embedding_identity = None
        if previous is not None:
            try:
                previous.close()
            except Exception:
                pass
        self.connection = self._open_connection()
        return dict(target=self.target, reconnected=True, server_cancel_confirmed=False)

    def __enter__(self):
        return self

    def __exit__(self, *unused):
        self.close()

    @staticmethod
    def _failure(error):
        code = re.match(r"(\d+)\s*-", str(error))
        return RuntimeError("Machbase SQL 실행 실패" + (" (코드 " + code[1] + ")" if code else "") +
                            ". 대상 서버 기능·스키마와 실행 로그를 확인하세요")

    def _execute(self, sql, params=None, *, prepared=True):
        if self.connection is None:
            raise RuntimeError("DB 연결이 닫혔습니다. 연결 옵션을 확인한 뒤 다시 연결하세요")
        cursor = self.connection.cursor(prepared=prepared)
        interrupted = False
        try:
            lexical = re.sub(r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|--[^\n]*", "", sql)
            names = set(re.findall(r":([A-Za-z_]\w*)", lexical))
            arguments = {key: params[key] for key in names} if names else None
            cursor.execute(sql, arguments)
            if re.match(r"\s*(SELECT|WITH|EXPLAIN|SHOW|DESC)\b", lexical, re.I):
                return [{str(key).lower(): value for key, value in row.items()} for row in cursor.fetchall()]
            return []
        except KeyboardInterrupt:
            # 중단된 프로토콜에서 FREE 응답을 기다리면 취소 처리가 다시 막힌다.
            interrupted = True
            try:
                self.close()
            except Exception:
                pass
            raise
        except (KeyError, ValueError):
            raise
        except Exception as error:
            raise self._failure(error) from None
        finally:
            if not interrupted:
                cursor.close()

    def _sql(self, filename):
        return (SQL / filename).read_text()

    def _existing(self):
        rows = self._execute("SELECT NAME FROM M$SYS_TABLES WHERE NAME IN (" +
                             ",".join("'" + PREFIX + value[0] + "'" for value in TABLES.values()) + ")")
        return {row["name"].upper() for row in rows}

    def _require_schema(self):
        expected = {PREFIX + value[0] for value in TABLES.values()}
        if self._existing() != expected:
            raise ValueError("GRRAG_ 전용 테이블 5개가 필요합니다. 빈 이름 공간에서 init을 명시적으로 실행하세요")

    def _manifest(self):
        rows = self._execute("SELECT state,external_key,source_uri FROM GRRAG_DOCUMENT "
                             "WHERE document_id=:id AND kb_id=:id", {"id": MANIFEST_ID})
        if not rows:
            return None
        row = rows[0]
        try:
            row["metadata"] = json.loads(row["source_uri"])
            metadata = row["metadata"]
            if not isinstance(metadata, dict) or not isinstance(metadata.get("embedding"), dict) or not isinstance(metadata.get("counts"), dict):
                raise ValueError("manifest shape")
            embedding = metadata["embedding"]
            counts = metadata["counts"]
            if (embedding.get("dimensions") != DIMENSIONS or
                not isinstance(embedding.get("model"), str) or not embedding["model"] or
                not isinstance(embedding.get("digest"), str) or not embedding["digest"] or
                set(counts) != set(TABLES) or
                any(isinstance(count, bool) or not isinstance(count, int) or count < 0 for count in counts.values())):
                raise ValueError("manifest model/counts")
            metadata["semantic_validation"] = _semantic_validation(metadata.get("semantic_validation"))
        except (TypeError, ValueError):
            raise ValueError("GRRAG_ manifest가 올바르지 않습니다. 기존 데이터를 덮어쓰지 않습니다") from None
        return row

    def doctor(self):
        one = self._execute("SELECT 1 AS N")
        recursive = self._execute("WITH RECURSIVE R(N) AS(SELECT CAST(1 AS LONG) UNION ALL "
                                  "SELECT N+1 FROM R WHERE N<3) SELECT N FROM R ORDER BY N")
        vector = self._execute("SELECT VECTOR_DIM(TO_VECTOR(:v,1024)) AS N",
                               {"v": json.dumps([1.0] + [0.0] * 1023)})
        return dict(target=self.target, connected=one == [{"n": 1}], recursive=recursive ==
                    [{"n": 1}, {"n": 2}, {"n": 3}], embedding_dimensions=vector[0]["n"],
                    tables=sorted(self._existing()), database_mutated=False)

    def init(self):
        existing = self._existing()
        if existing:
            raise ValueError("GRRAG_ 이름 충돌: " + ", ".join(sorted(existing)) + ". 기존 데이터는 변경하지 않았습니다")
        completed = 0
        try:
            for sql in split_sql(self._sql("01_schema.sql")):
                self._execute(sql)
                completed += 1
        except Exception:
            raise RuntimeError("init이 " + str(completed) + "개 statement 뒤 실패했습니다. "
                               "부분 생성된 GRRAG_ 객체를 검토하세요. 자동 삭제하지 않습니다") from None
        return dict(created=sorted(self._existing()), statements=completed)

    def status(self):
        tables = self._existing()
        if len(tables) != len(TABLES):
            return dict(target=self.target, ready=False, tables=sorted(tables), counts={}, manifest=None,
                        integrity="SCHEMA_INCOMPLETE")
        counts = {}
        for key, (suffix, primary, columns) in TABLES.items():
            where = " WHERE document_id<>:marker" if key == "documents" else ""
            counts[key] = self._execute("SELECT COUNT(*) AS N FROM " + PREFIX + suffix + where,
                                        {"marker": MANIFEST_ID})[0]["n"]
        marker = self._manifest()
        matched = bool(marker and counts == marker["metadata"]["counts"])
        return dict(target=self.target, ready=bool(matched and marker["state"] == "LOADED"),
                    tables=sorted(tables), counts=counts, manifest=marker,
                    integrity="MATCHED" if matched else "COUNT_MISMATCH" if marker else "NO_MANIFEST")

    def concept(self, node_id):
        """로컬 캐시 대신 현재 연결 DB의 개념·관계와 게시된 원문 근거를 조회한다."""
        identity = _id(node_id, "node_id")
        metadata = self._loaded()
        params = dict(kb_id=1, node_id=identity)
        columns = ",".join(field for field in TABLES["nodes"][2] if field != "embedding")
        nodes = self._execute("SELECT " + columns + " FROM GRRAG_NODE "
                              "WHERE kb_id=:kb_id AND node_id=:node_id", params)
        if not nodes:
            return dict(nodes=[], edges=[], evidence=[], trace=dict(source="database", node_id=identity))
        scope_column=',E.scope_json' if metadata.get('schema_version',1)>=2 else ''
        edges = self._execute("""
            SELECT E.edge_id,E.source_id,S.label AS source_label,E.predicate_id,
                   P.code AS predicate_code,E.target_id,T.label AS target_label,E.state"""+scope_column+"""
            FROM GRRAG_EDGE E,GRRAG_NODE S,GRRAG_NODE P,GRRAG_NODE T
            WHERE E.kb_id=:kb_id AND (E.source_id=:node_id OR E.target_id=:node_id)
              AND S.node_id=E.source_id AND S.kb_id=E.kb_id
              AND P.node_id=E.predicate_id AND P.kb_id=E.kb_id
              AND T.node_id=E.target_id AND T.kb_id=E.kb_id
            ORDER BY E.edge_id
        """, params)
        evidence = self._execute("""
            SELECT V.evidence_id,V.target_kind,V.target_id,V.quote,C.chunk_id,
                   C.locator,C.body,D.document_id,D.title,D.source_uri,C.document_version
            FROM GRRAG_EVIDENCE V,GRRAG_CHUNK C,GRRAG_DOCUMENT D
            WHERE V.kb_id=:kb_id AND C.chunk_id=V.chunk_id AND C.kb_id=V.kb_id
              AND D.document_id=C.document_id AND D.kb_id=C.kb_id
              AND D.state='PUBLISHED' AND D.current_version=C.document_version
              AND ((V.target_kind='NODE' AND V.target_id=:node_id)
                   OR (V.target_kind='EDGE' AND V.target_id IN (
                       SELECT E.edge_id FROM GRRAG_EDGE E WHERE E.kb_id=:kb_id
                         AND (E.source_id=:node_id OR E.target_id=:node_id))))
            ORDER BY V.target_kind,V.target_id,V.evidence_id
        """, params)
        return dict(nodes=nodes, edges=edges, evidence=evidence,
                    trace=dict(source="database", target=self.target, node_id=identity,
                               embedding=metadata["embedding"],
                               evidence_visibility="현재 PUBLISHED 문서 버전",
                               snapshot_scope="같은 연결의 세 SELECT; 각 SQL의 읽기 snapshot"))

    def ontology_facts(self,seeds):
        """schema2의 시작점 인접 승인 명제와 현재 원문을 한 SQL로 반환한다."""
        metadata=self._loaded()
        if metadata.get('schema_version',1)<2 or not seeds:return []
        ids=list(dict.fromkeys(_id(s['node_id'],'seed_id') for s in seeds))
        params={'kb':1};markers=[]
        for index,nid in enumerate(ids):params['n'+str(index)]=nid;markers.append(':n'+str(index))
        selected=','.join(markers)
        sql=self._sql('09_ontology_facts.sql').replace('__SEED_IDS__',selected)
        self.last_fact_query=dict(sql=sql,parameters=params)
        rows=self._execute(sql,params)
        grouped={}
        for row in rows:
            fact=grouped.setdefault(row['edge_id'],{key:row[key] for key in ('edge_id','source_id','subject','predicate_code','target_id','object_label')})
            fact.setdefault('scope',json.loads(row['scope_json']));fact.setdefault('evidence',[])
            evidence={key:row[key] for key in ('quote','chunk_id','locator','source_uri','title')}
            evidence['context_body']=row['body']
            if evidence not in fact['evidence']:fact['evidence'].append(evidence)
        return list(grouped.values())

    def answer_context(self,sources):
        """첫 명제의 같은 문서·버전에서 앞뒤 두 청크를 읽어 SQL 예제 문맥을 보충한다."""
        if not sources:return []
        sql="""SELECT C.chunk_id,C.body,C.locator,D.source_uri,D.title
            FROM GRRAG_CHUNK A,GRRAG_CHUNK C,GRRAG_DOCUMENT D
            WHERE A.kb_id=:kb AND A.chunk_id=:anchor
              AND C.kb_id=:kb AND C.document_id=A.document_id
              AND C.document_version=A.document_version
              AND C.ordinal>=A.ordinal-2 AND C.ordinal<=A.ordinal+2
              AND D.kb_id=:kb AND D.document_id=C.document_id
              AND D.state='PUBLISHED' AND D.current_version=C.document_version
            ORDER BY C.ordinal"""
        params={'kb':1,'anchor':_id(sources[0]['chunk_id'])}
        self.last_context_query=dict(sql=sql,parameters=params)
        return self._execute(sql,params)

    def _validate_snapshot(self, snapshot):
        if not isinstance(snapshot, dict):
            raise ValueError("snapshot은 객체여야 합니다")
        manifest = snapshot.get("manifest", {})
        if manifest.get("complete") is not True:
            raise ValueError("완료되지 않은 추출 snapshot은 게시할 수 없습니다")
        semantic_validation = _semantic_validation(manifest.get("semantic_validation"))
        embedding = manifest.get("embedding", {})
        if embedding.get("dimensions") != DIMENSIONS or not isinstance(embedding.get("model"), str) or not embedding["model"] or not isinstance(embedding.get("digest"), str) or not embedding["digest"]:
            raise ValueError("snapshot manifest에 embedding model/digest/dimensions=1024가 필요합니다")
        ids = {}
        for key, (suffix, primary, columns) in TABLES.items():
            rows = snapshot.get(key)
            if not isinstance(rows, list):
                raise ValueError("snapshot." + key + "는 배열이어야 합니다")
            ids[key] = set()
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError(key + "의 각 행은 객체여야 합니다")
                identity = _id(row.get(primary), primary)
                if identity in ids[key]:
                    raise ValueError(key + "의 ID가 중복되었습니다")
                ids[key].add(identity)
                if row.get("kb_id") != 1 or isinstance(row.get("kb_id"), bool):
                    raise ValueError("데모 snapshot의 kb_id는 1이어야 합니다")
                required = {
                    "documents": ("title", "source_uri", "current_version", "state"),
                    "chunks": ("document_id", "document_version", "ordinal", "locator", "body", "analysis_state"),
                    "nodes": ("node_kind", "label", "state"),
                    "edges": ("state",),
                    "evidence": ("target_kind", "target_id", "chunk_id", "quote"),
                }[key]
                if any(row.get(field) is None or row.get(field) == "" for field in required):
                    raise ValueError(key + "의 필수 필드가 없습니다")
                for field in ("document_id", "document_version", "current_version", "source_id", "predicate_id", "target_id", "canonical_id", "canonical_edge_id", "chunk_id"):
                    if row.get(field) is not None:
                        _id(row[field], key + "." + field)
                if key == "chunks" and (isinstance(row["ordinal"], bool) or not isinstance(row["ordinal"], int) or not 0 < row["ordinal"] < (1 << 31)):
                    raise ValueError("chunk ordinal은 양수 INTEGER이어야 합니다")
                for field, width in WIDTHS[key].items():
                    value = row.get(field)
                    if value is not None and (not isinstance(value, str) or len(value.encode()) > width):
                        raise ValueError(key + "." + field + "가 VARCHAR byte 한도 " + str(width) + "를 넘었습니다")
                if key == "chunks" and row.get("fact_count") is not None:
                    count = row["fact_count"]
                    if isinstance(count, bool) or not isinstance(count, int) or not 0 <= count < (1 << 31):
                        raise ValueError("chunk fact_count는 0 이상의 INTEGER이어야 합니다")
                if key == "nodes" and row.get("search_text") is not None:
                    if not isinstance(row["search_text"], str) or len(row["search_text"].encode()) > 64 * 1024 * 1024:
                        raise ValueError("node search_text는 64MiB 이하 TEXT여야 합니다")
                if key in ("chunks", "nodes") and row.get("embedding") is not None:
                    _vector(row["embedding"])
                if key == "chunks" and row.get("embedding") is None:
                    raise ValueError("적재할 모든 chunk에 임베딩이 필요합니다")
        documents = {row["document_id"]: row for row in snapshot["documents"]}
        nodes = {row["node_id"]: row for row in snapshot["nodes"]}
        chunks = {row["chunk_id"]: row for row in snapshot["chunks"]}
        for row in snapshot["chunks"]:
            if row.get("document_id") not in ids["documents"] or not isinstance(row.get("body"), str) or not row["body"]:
                raise ValueError("chunk의 문자열 원문/document 참조가 필요합니다")
            if len(row["body"].encode()) > 64 * 1024 * 1024:
                raise ValueError("chunk body가 TEXT 64MiB 한도를 넘었습니다")
            if row.get("document_version") != documents[row["document_id"]].get("current_version"):
                raise ValueError("chunk document_version이 현재 문서 버전과 다릅니다")
        for row in snapshot["nodes"]:
            if row.get("node_kind") not in NODE_KINDS:
                raise ValueError("지원하지 않는 node_kind입니다")
            if row["node_kind"] == "ALIAS" and row.get("canonical_id") not in ids["nodes"]:
                raise ValueError("ALIAS canonical_id가 없습니다")
            if row["node_kind"] == "RELATION_TYPE" and row.get("code") not in RELATIONS:
                raise ValueError("지원하지 않는 관계 코드입니다")
        for row in snapshot["edges"]:
            if any(row.get(field) not in ids["nodes"] for field in ("source_id", "predicate_id", "target_id")):
                raise ValueError("edge의 source/predicate/target 참조가 없습니다")
            predicate = nodes[row["predicate_id"]]
            if predicate["node_kind"] != "RELATION_TYPE" or predicate.get("source_kind") != nodes[row["source_id"]]["node_kind"] or predicate.get("target_kind") != nodes[row["target_id"]]["node_kind"]:
                raise ValueError("edge의 관계 타입과 양 끝 node_kind가 다릅니다")
        for row in snapshot["evidence"]:
            target = "nodes" if row.get("target_kind") == "NODE" else "edges" if row.get("target_kind") == "EDGE" else None
            if target is None or row.get("target_id") not in ids[target] or row.get("chunk_id") not in chunks:
                raise ValueError("evidence 대상/원문 참조가 없습니다")
            if not row.get("quote") or row["quote"] not in chunks[row["chunk_id"]]["body"]:
                raise ValueError("evidence quote가 해당 chunk 원문에 없습니다")
        if manifest.get('schema_version',1)>=2:
            from semantic_gate import verify as publication_gate
            gate=publication_gate(snapshot)
            if gate['status']!='PASS':raise ValueError('의미 온톨로지 게시 계약 위반: '+str(gate['errors'][:5]))
        return dict(embedding=embedding, counts={key: len(snapshot[key]) for key in TABLES},
                    semantic_validation=semantic_validation,schema_version=manifest.get('schema_version',1),
                    ontology_scope=manifest.get('ontology_scope'))

    def load(self, snapshot):
        metadata = self._validate_snapshot(snapshot)
        digest = snapshot_hash(snapshot)
        metadata_json = json.dumps(metadata, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        if len(metadata_json.encode()) > 1024:
            raise ValueError("embedding manifest metadata가 VARCHAR(1024) 한도를 넘었습니다")
        self._require_schema()
        state = self.status()
        marker = state["manifest"]
        if marker:
            if marker["state"] == "LOADED" and marker["external_key"] == digest and state["counts"] == metadata["counts"]:
                return dict(status="unchanged", snapshot_sha256=digest, counts=metadata["counts"],
                            semantic_validation=metadata["semantic_validation"])
            raise ValueError("기존 GRRAG_ snapshot이 다르거나 불완전합니다. 자동 덮어쓰기/삭제하지 않습니다")
        if any(state["counts"].values()):
            raise ValueError("manifest 없는 GRRAG_ 데이터가 있습니다. 자동 덮어쓰기/삭제하지 않습니다")
        self._execute("INSERT INTO GRRAG_DOCUMENT VALUES(:id,:id,'GraphRAG demo manifest',:metadata,1,'LOADING',:hash)",
                      {"id": MANIFEST_ID, "metadata": metadata_json, "hash": digest})
        written = {key: 0 for key in TABLES}
        try:
            for key, (suffix, primary, columns) in TABLES.items():
                expressions = ["TO_VECTOR(:embedding,1024)" if field == "embedding" else ":" + field for field in columns]
                sql = "INSERT INTO " + PREFIX + suffix + "(" + ",".join(columns) + ") VALUES(" + ",".join(expressions) + ")"
                cursor = self.connection.cursor(prepared=True)
                try:
                    for row in snapshot[key]:
                        params = {field: row.get(field) for field in columns}
                        if "embedding" in params:
                            params["embedding"] = json.dumps(_vector(params["embedding"])) if params["embedding"] is not None else None
                        cursor.execute(sql, params)
                        written[key] += 1
                finally:
                    cursor.close()
            self._execute("ALTER INDEX GRRAG_NODE_BM25 WAIT TIMEOUT 60")
            self._execute("ALTER INDEX GRRAG_CHUNK_BM25 WAIT TIMEOUT 60")
            self._execute("UPDATE GRRAG_DOCUMENT SET state='LOADED' WHERE document_id=:id", {"id": MANIFEST_ID})
        except Exception:
            raise RuntimeError("snapshot 적재가 중단되었습니다. LOADING manifest와 부분 데이터는 보존했습니다. "
                               "자동 삭제/재적재하지 않습니다. 적재 건수: " + json.dumps(written)) from None
        return dict(status="loaded", snapshot_sha256=digest, counts=written, embedding=metadata["embedding"],
                    semantic_validation=metadata["semantic_validation"])

    def _loaded(self):
        self._require_schema()
        marker = self._manifest()
        if not marker or marker["state"] != "LOADED":
            raise ValueError("검색 전에 정상 완료된 snapshot을 load하세요")
        return marker["metadata"]

    def check_embedding(self, model, digest=None):
        metadata = self._loaded()["embedding"]
        if not isinstance(digest, str) or not digest:
            raise ValueError("질문 임베딩의 실제 모델 digest를 확인해야 합니다")
        if model != metadata["model"] or digest != metadata["digest"]:
            raise ValueError("질문 임베딩 모델/digest가 적재된 snapshot과 다릅니다. 해당 모델로 생성한 snapshot을 사용하세요")
        self.embedding_identity = dict(model=model, digest=digest)
        return metadata

    def _params(self, question, vector, depth, top_k, policy="context"):
        if not isinstance(question, str) or not question.strip():
            raise ValueError("질문을 입력하세요")
        if isinstance(depth, bool) or not isinstance(depth, int) or not 0 <= depth <= 4:
            raise ValueError("depth는 0..4이어야 합니다")
        if isinstance(top_k, bool) or not isinstance(top_k, int) or not 1 <= top_k <= 100:
            raise ValueError("top_k는 1..100이어야 합니다")
        if policy not in ("context", "taxonomy"):
            raise ValueError("policy는 context/taxonomy이어야 합니다")
        return dict(kb_id=1, question=question.strip(), node_query_vector_json=json.dumps(_vector(vector)),
                    chunk_query_vector_json=json.dumps(_vector(vector)), max_depth=depth,
                    document_k=top_k, policy=policy)

    def _seeds(self, params, seeds):
        if seeds is None:
            return self._execute(self._sql("02_seed_search.sql"), params)
        if not isinstance(seeds, (list, tuple)) or len(seeds) > 3:
            raise ValueError("seeds에는 최대 3개의 positive LONG ID를 지정하세요")
        normalized = []
        seen = set()
        for item in seeds:
            identity = _id(item.get("node_id", item.get("seed_id")) if isinstance(item, dict) else item, "seed_id")
            if identity not in seen:
                row = dict(item) if isinstance(item, dict) else {}
                score = row.get("seed_score", 1.0)
                if isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(score):
                    raise ValueError("seed_score는 유한 숫자여야 합니다")
                row.update(node_id=identity, seed_score=float(score),
                           match_method=row.get("match_method", "EXPLICIT"))
                normalized.append(row)
                seen.add(identity)
        return normalized

    def discover_seeds(self, question, vector, terms, policy="context"):
        """LLM이 제안한 용어는 별칭으로 확인하고 부족한 seed는 의미 검색한다."""
        self._loaded()
        params = self._params(question, vector, 0, 3, policy)
        if not isinstance(terms, list) or len(terms) > 12:
            raise ValueError("concept terms는 최대 12개 문자열 배열이어야 합니다")
        keys = []
        for term in terms:
            if not isinstance(term, str):
                raise ValueError("concept term은 문자열이어야 합니다")
            key = " ".join(unicodedata.normalize("NFC", term).casefold().split())
            if not key:
                continue
            if len(key.encode()) > 256:
                raise ValueError("정규화한 concept term이 별칭 VARCHAR(256) byte 한도를 넘었습니다")
            if key not in keys:
                keys.append(key)
        selected, seen = [], set()
        if keys:
            markers = []
            for index, key in enumerate(keys):
                name = "alias_" + str(index)
                params[name] = key
                markers.append(":" + name)
            sql = self._sql("05_alias_search.sql").replace("__ALIAS_KEYS__", ",".join(markers))
            exact = self._execute(sql, params)
            # 용어 제안 순서를 유지하며 같은 canonical의 여러 별칭은 하나로 묶는다.
            priority = {key: index for index, key in enumerate(keys)}
            exact.sort(key=lambda row: (priority.get(row.get("matched_alias"), len(keys)), row["node_id"]))
            for row in exact:
                if row["node_id"] not in seen:
                    selected.append(row)
                    seen.add(row["node_id"])
                    if len(selected) == 3:
                        return selected
        for row in self._execute(self._sql("02_seed_search.sql"), params):
            if row["node_id"] not in seen:
                selected.append(row)
                seen.add(row["node_id"])
                if len(selected) == 3:
                    break
        return selected

    def _graph_sql(self, selected, params, schema_version=1):
        seed_ids, cases = [], []
        for index, row in enumerate(selected):
            key = "seed_" + str(index)
            score = "score_" + str(index)
            params[key] = _id(row["node_id"], "seed_id")
            params[score] = float(row.get("seed_score") or 0.0)
            seed_ids.append(":" + key)
            cases.append("WHEN N.node_id=:" + key + " THEN :" + score)
        if not selected:
            params["seed_0"] = -999
            params["score_0"] = 0.0
            seed_ids = [":seed_0"]
            cases = ["WHEN N.node_id=:seed_0 THEN :score_0"]
        template = self._sql("07_graph_search_scoped.sql" if schema_version>=2 else "03_graph_search.sql")
        if getattr(self, "graph_strategy", "shared") == "shared":
            template = build_shared_query(template)
        return template.replace("__SEED_IDS__", ",".join(seed_ids)).replace(
            "__SEED_SCORE__", "CASE " + " ".join(cases) + " ELSE 0.0 END")

    def search(self, question, vector, seeds=None, depth=2, top_k=5, mode="hybrid", policy="context"):
        if mode not in ("hybrid", "graph", "direct"):
            raise ValueError("mode는 hybrid/graph/direct여야 합니다")
        began = time.monotonic()
        metadata = self._loaded()
        params = self._params(question, vector, depth, top_k, policy)
        selected = [] if mode == "direct" else self._seeds(params, seeds)
        version=metadata.get('schema_version',1)
        sql = self._sql("04_direct_search.sql") if mode == "direct" else self._graph_sql(selected, params,version)
        rows = self._execute(sql, params)
        hits = [row for row in rows if row.get("record_type") == "HIT"] if mode != "direct" else rows
        paths = [row for row in rows if row.get("record_type") != "HIT"] if mode != "direct" else []
        for row in paths:
            if row.get('scope_json'):row['scope']=json.loads(row['scope_json'])
        fallback = mode == "hybrid" and not hits
        if fallback:
            hits = self._execute(self._sql("04_direct_search.sql"), params)
        for row in hits:
            row.setdefault("chunk_id", row.get("hit_chunk_id"))
            if isinstance(row.get("source_uri"), str) and row["source_uri"].startswith("file:"):
                row["source_path"] = row["source_uri"][5:]
        return dict(hits=hits, paths=paths, seeds=selected,
                    trace=dict(mode=mode, policy=policy, fallback=fallback, depth=depth, top_k=top_k,
                               graph_strategy=getattr(self, "graph_strategy", "shared"),
                               sql_file="04_direct_search.sql" if mode == "direct" else
                                   ("08_graph_search_scoped_shared.sql" if getattr(self,"graph_strategy","shared")=="shared" else "07_graph_search_scoped.sql") if version>=2 else
                                   "06_graph_search_shared.sql" if getattr(self, "graph_strategy", "shared") == "shared" else "03_graph_search.sql",
                               embedding=metadata["embedding"], embedding_identity_checked=self.embedding_identity,
                               semantic_validation=metadata.get("semantic_validation"),
                               ontology_scope=metadata.get('ontology_scope'),
                               elapsed=time.monotonic() - began,
                               traversal="양방향 문맥; F/R은 원래 관계 방향", snapshot_scope="그래프 검색 단일 SQL; fallback은 별도 SQL"))

    def explain_search(self, question, vector, seeds=None, depth=2, top_k=5, mode="hybrid", full=False,
                       policy="context"):
        if mode not in ("hybrid", "graph", "direct"):
            raise ValueError("mode는 hybrid/graph/direct여야 합니다")
        metadata=self._loaded()
        params = self._params(question, vector, depth, top_k, policy)
        selected = [] if mode == "direct" else self._seeds(params, seeds)
        version=metadata.get('schema_version',1)
        sql = self._sql("04_direct_search.sql") if mode == "direct" else self._graph_sql(selected, params,version)
        rendered = render_sql(sql, params)
        began = time.monotonic()
        rows = self._execute("EXPLAIN " + ("FULL " if full else "") + rendered, prepared=False)
        plan = "\n".join(str(value) for row in rows for value in row.values())
        operators = bool(re.search(r"^\s*(?:PROJECT(?:\s|$)|[^\n]*\bSCAN\s*\(|HYBRID SEARCH\s*\(|RECURSIVE CTE\b)", plan, re.MULTILINE))
        scans = [line for line in plan.splitlines() if "FULL SCAN" in line.upper()]
        structural = [line for line in scans if any(name in line.upper() for name in
                      ("GRRAG_EDGE", "GRRAG_EVIDENCE", "GRRAG_DOCUMENT", "GRRAG_NODE"))]
        return dict(sql=sql, rendered_sql=rendered, parameters=params, seeds=selected, plan=plan,
                    policy=policy,
                    graph_strategy=getattr(self, "graph_strategy", "shared"),
                    sql_file="04_direct_search.sql" if mode == "direct" else
                        ("08_graph_search_scoped_shared.sql" if getattr(self,"graph_strategy","shared")=="shared" else "07_graph_search_scoped.sql") if version>=2 else
                        "06_graph_search_shared.sql" if getattr(self, "graph_strategy", "shared") == "shared" else "03_graph_search.sql",
                    full=bool(full), elapsed=time.monotonic() - began, full_scans=scans,
                    operator_plan_present=operators,
                    scan_assessment=("NOT_AVAILABLE_PROFILE_ONLY" if not operators else
                                     "FULL_SCAN_OPERATOR_OBSERVED" if scans else "NO_FULL_SCAN_OPERATOR_OBSERVED"),
                    structural_full_scans=structural,
                    interpretation="MODE EXACT의 검색 후보 읽기는 예상 비용입니다. 구조 관계 FULL SCAN은 JOIN 위치와 실행 통계를 확인해야 하며 이 목록만으로 반복 스캔을 단정하지 않습니다")


DemoDB = Database
