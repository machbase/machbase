"""파일·줄·SHA를 보존하는 Markdown 문서 분할."""
import hashlib
from pathlib import Path
import re


TARGET_CHARS = 1200
MAX_CHARS = 3000
OVERLAP_CHARS = 400
CHUNK_VERSION = "markdown-lines-v2"


def utf8_prefix(value, maximum):
    """VARCHAR 바이트 한도에서 UTF-8 문자를 자르지 않는다."""
    return value.encode("utf-8")[:maximum].decode("utf-8", errors="ignore")


def embedding_text(body):
    """검색 의미가 없는 숨김 anchor를 제외하고 원문 body는 보존한다."""
    return re.sub(r"<a\s+(?:id|name)\s*=\s*['\"][^'\"]*['\"]\s*>\s*</a>", "", body,
                  flags=re.IGNORECASE).strip()


def stable_id(kind, value):
    """재실행에도 같은 양수 LONG 키를 만든다."""
    digest = hashlib.sha256((kind + "\0" + value).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % ((1 << 63) - 1) + 1


def collect(source):
    source = Path(source).resolve(strict=True)
    files = sorted(source.rglob("*.md")) if source.is_dir() else [source]
    if not files:
        raise ValueError("Markdown 원문이 없습니다: " + str(source))
    documents, chunks, manifest, issues = [], [], [], []
    for path in files:
        relative = path.relative_to(source).as_posix() if source.is_dir() else path.name
        raw = path.read_bytes()
        text = raw.decode("utf-8")
        sha = hashlib.sha256(raw).hexdigest()
        lines = text.splitlines(keepends=True)
        first_line, front_title = 0, None
        if lines and lines[0].strip() == "---":
            close = next((i for i in range(1, len(lines)) if lines[i].strip() == "---"), None)
            if close is not None:
                for line in lines[1:close]:
                    match = re.match(r"^title:\s*(.*?)\s*$", line)
                    if match:
                        front_title = match.group(1).strip("'\"")
                first_line = close + 1
        title = front_title or next((line.lstrip("#").strip() for line in lines[first_line:]
                                     if line.startswith("# ")), path.stem)
        document_id = stable_id("document", relative)
        documents.append(dict(document_id=document_id, kb_id=1, title=utf8_prefix(title, 256),
                              source_uri=utf8_prefix("file:" + relative, 1024), current_version=1, state="PUBLISHED",
                              external_key=utf8_prefix(relative, 256), source_sha256=sha))
        # 긴 한 줄도 원문에서 잘라 최대 길이를 지키며 줄 번호는 유지한다.
        units, headings = [], []
        fenced = False
        for line_no, line in enumerate(lines, 1):
            if line_no <= first_line:
                continue
            if line.lstrip().startswith(("```", "~~~")):
                fenced = not fenced
            match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line) if not fenced else None
            if match:
                level = len(match.group(1))
                headings = [(depth, label) for depth, label in headings if depth < level]
                headings.append((level, match.group(2)))
            heading = " > ".join([title] + [label for _, label in headings])
            for offset in range(0, len(line), MAX_CHARS):
                units.append((line[offset:offset + MAX_CHARS], line_no, heading))
        start, ordinal = 0, 1
        while start < len(units):
            end, length = start, 0
            while end < len(units):
                size = len(units[end][0])
                if end > start and length + size > MAX_CHARS:
                    break
                length += size
                end += 1
                if length >= TARGET_CHARS:
                    break
            body = "".join(unit[0] for unit in units[start:end])
            cleaned = embedding_text(body)
            if cleaned:
                first, last = units[start][1], units[end - 1][1]
                body_sha = hashlib.sha256(body.encode("utf-8")).hexdigest()
                chunk_id = stable_id("chunk", relative + ":" + str(ordinal) + ":" + body_sha)
                chunks.append(dict(chunk_id=chunk_id, kb_id=1, document_id=document_id,
                                   document_version=1, ordinal=ordinal,
                                   locator=utf8_prefix(relative + ":L" + str(first) + "-L" + str(last), 256),
                                   body=body, embedding=None, analysis_state="PENDING",
                                   extractor_version=None, fact_count=None, source_path=relative,
                                   line_start=first, line_end=last, source_sha256=sha,
                                   heading=units[start][2], body_sha256=body_sha,
                                   embedding_text=cleaned, embedding_text_sha256=hashlib.sha256(
                                       cleaned.encode("utf-8")).hexdigest()))
                ordinal += 1
            if end == len(units):
                break
            # 가능한 줄 단위로 최대 400자를 겹치며 반드시 앞으로 진행한다.
            overlap, next_start = 0, end
            while next_start > start + 1 and overlap + len(units[next_start - 1][0]) <= OVERLAP_CHARS:
                next_start -= 1
                overlap += len(units[next_start][0])
            start = next_start
        manifest.append(dict(path=relative, sha256=sha, bytes=len(raw), lines=len(lines),
                             chunks=ordinal - 1))
    return dict(documents=documents, chunks=chunks, manifest=dict(chunk_version=CHUNK_VERSION,
                target_chars=TARGET_CHARS, max_chars=MAX_CHARS, overlap_chars=OVERLAP_CHARS,
                files=manifest), issues=issues)
