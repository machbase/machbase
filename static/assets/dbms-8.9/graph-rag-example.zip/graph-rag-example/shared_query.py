"""검토된 그래프 SQL의 공통 CTE를 한 번 생성하고 공유하도록 변환한다.

사용자 SQL 변환기가 아니다. 고정한 03_graph_search.sql 템플릿만 받으며 질문·ID·벡터
값은 이 함수에 전달하지 않는다. 실제 그래프 반복은 walk가 수행한다. 나머지 CTE의
자기 참조 분기는 WHERE 1=0이라 행을 추가하지 않고 기존 #4382 공유 producer를 선택한다.
"""
from functools import lru_cache
import re

FIELDS = {
    'readable_chunks': 'chunk_id,kb_id,document_id,document_version,locator,body,title,source_uri',
    'readable_nodes': 'node_id,node_kind,label',
    'readable_edges': 'edge_id,source_id,predicate_id,target_id,predicate_code',
    'seeds': 'seed_id,seed_score',
    'arcs': 'edge_id,from_id,to_id,predicate_id,predicate_code,direction',
    'best_nodes': 'seed_id,node_id,depth,from_id,edge_id,predicate_id,predicate_code,direction,route_key,node_path',
    'candidate_routes': 'seed_id,node_id,depth,route_key,chunk_id,attachment_kind,attachment_id,source_ref,quote',
    'candidate_keys': 'chunk_id',
    'hits': 'chunk_id,document_score',
    'picked_routes': 'seed_id,node_id,depth,route_key,chunk_id,attachment_kind,attachment_id,source_ref,quote',
    'path_steps': 'chunk_id,seed_id,route_key,step_no,from_id,edge_id,predicate_id,predicate_code,to_id,direction',
}
CTE_ORDER = ('readable_chunks', 'readable_nodes', 'readable_edges', 'seeds', 'arcs', 'walk',
             'best_nodes', 'candidate_routes', 'candidate_keys', 'hits', 'picked_routes', 'path_steps', 'result_rows')
COMPOUND_ANCHORS = frozenset(('arcs', 'candidate_routes'))
HEADER = '-- shared_query.build_shared_query로 03_graph_search.sql에서 생성. 원본과 동기화 테스트 필요.\n'


def _mask_literals(sql):
    token = re.compile(r"'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|--[^\n]*|/\*.*?\*/", re.S)
    return token.sub(lambda match: ''.join('\n' if char == '\n' else ' ' for char in match[0]), sql)


@lru_cache(maxsize=1)
def build_shared_query(sql):
    """고정 CTE 이름·순서·출력 필드를 확인하고 데이터 값 없이 SQL 형태만 생성한다."""
    masked = _mask_literals(sql)
    if not re.search(r'\bWITH\s+RECURSIVE\b', masked):
        raise ValueError('공유 전략에는 검토된 WITH RECURSIVE 그래프 템플릿이 필요합니다')
    definitions = list(re.finditer(r'(?m)^([a-z_]+)(?:\([^\n)]*\))? AS \(', masked))
    if tuple(match[1] for match in definitions) != CTE_ORDER:
        raise ValueError('그래프 SQL의 CTE 이름/순서가 바뀌었습니다. 고정 출력 필드를 다시 검토하세요')
    parts, cursor = [], 0
    for index, match in enumerate(definitions):
        depth, end = 1, match.end()
        while depth and end < len(masked):
            if masked[end] == '(':
                depth += 1
            elif masked[end] == ')':
                depth -= 1
            end += 1
        if depth:
            raise ValueError('그래프 SQL의 CTE 괄호가 닫히지 않았습니다')
        if index + 1 < len(definitions) and masked[end:definitions[index + 1].start()].strip() != ',':
            raise ValueError('그래프 SQL의 CTE 경계를 다시 검토하세요')
        name = match[1]
        if name not in FIELDS:
            continue
        columns = FIELDS[name]
        body = sql[match.end():end - 1]
        if name in COMPOUND_ANCHORS:
            # compound 전체를 하나의 anchor SELECT로 감싸 재귀 UNION과 구분한다.
            body = '\n    SELECT * FROM (' + body + '\n    ) MATERIALIZE_ANCHOR\n'
        parts.extend((sql[cursor:match.start()], name + '(' + columns + ') AS (', body,
                      '\n    UNION ALL\n    SELECT ' + columns + ' FROM ' + name + ' WHERE 1=0\n'))
        cursor = end - 1
    parts.append(sql[cursor:])
    return HEADER + ''.join(parts)
