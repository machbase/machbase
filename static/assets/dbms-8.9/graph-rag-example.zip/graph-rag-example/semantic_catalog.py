"""지식 명제를 넣지 않는 source-grounded ontology concept 후보 목록."""
import hashlib
import json
from pathlib import Path
import re
from ontology import normalize

VERSION='semantic-concepts-v3'
# 개념/역할 사전이다. 지원 여부·제약 명제는 원문에서 별도로 추출한다.
EXTRA=[
 ('TAG_TIME_TABLE','Time-axis TAG','TableType',['시간축 TAG','time-axis TAG']),
 ('TAG_DISTANCE_TABLE','Distance-axis TAG','TableType',['거리축 TAG','distance-axis TAG']),
 ('SCALAR_METADATA','Scalar METADATA column','ColumnRole',['일반 스칼라 METADATA','scalar METADATA','scalar metadata']),
 ('ARRAY_METADATA','Numeric ARRAY METADATA column','ColumnRole',['숫자 ARRAY','numeric ARRAY','ARRAY metadata','ARRAY 메타데이터']),
 ('JSON_METADATA','JSON METADATA column','ColumnRole',['JSON METADATA','JSON 메타데이터','JSON metadata']),
 ('LAST_UPDATE_TIME','_LAST_UPDATE_TIME','ColumnRole',['_LAST_UPDATE_TIME','_last_update_time']),
 ('ARRIVAL_TIME','_ARRIVAL_TIME','ColumnRole',['_ARRIVAL_TIME','_arrival_time']),
 ('METADATA_DELETE','TAG METADATA DELETE','Operation',['METADATA 삭제','metadata deletion','DELETE FROM TAG METADATA']),
 ('METADATA_INSERT','TAG METADATA INSERT','Operation',['METADATA INSERT','metadata INSERT']),
 ('METADATA_ARRAY_ADD','METADATA ARRAY ADD COLUMN','Operation',['ADD COLUMN','ARRAY 컬럼 추가','add ARRAY']),
 ('METADATA_ARRAY_DEFAULT','METADATA ARRAY DEFAULT','SQLFeature',['ADD COLUMN DEFAULT','ARRAY DEFAULT','ARRAY 메타데이터 기본값']),
 ('AUTO_TAG_REGISTRATION','Automatic TAG registration','Operation',['자동 등록','automatically registered','automatic tag registration']),
 ('UPSERT','UPSERT','Operation',['UPSERT','ON DUPLICATE KEY UPDATE']),
 ('SPATIAL_INDEX','Spatial index','IndexType',['공간 인덱스','spatial index']),
 ('PATH_MATCHING','Path matching','SQLFeature',['경로 매칭','path matching']),
 ('AVG','AVG','SQLFeature',['AVG','평균']),
 ('CUMULATIVE_ENERGY','Cumulative energy reading','MeasurementType',['누적 계량값','누적 kWh','cumulative reading','cumulative energy']),
 ('INTERVAL_ENERGY','Interval energy usage','MeasurementType',['구간 사용량','interval consumption','interval usage']),
 ('RETENTION','Retention policy','SQLFeature',['Retention Policy','retention policy','보존 정책']),
 ('BATCH_ATOMICITY','Statement atomicity','OperationalProperty',['원자적','atomically','atomic','트랜잭션','transaction']),
 ('VALUE','VALUE column','ColumnRole',['__Value__','VALUE','value']),
 ('ARRAY_DATA','TAG DATA ARRAY column','ColumnRole',['TAG DATA ARRAY','ARRAY DATA columns']),
 ('VALUE_STATISTICS','Value statistics','SQLFeature',['value statistics','값 통계']),
 ('AUTO_ROLLUP','Automatic WITH ROLLUP','SQLFeature',['WITH ROLLUP','automatic ROLLUP']),
 ('JSON_DOCUMENT_ROLLUP','Whole JSON document ROLLUP','SQLFeature',['whole-JSON-document ROLLUP']),
 ('FIXED_BINARY','BINARY(n)','ColumnRole',['BINARY(n)']),
 ('TABLE_DROP','DROP TABLE','Operation',['DROP TABLE']),
 ('TAG_DATA_ALTER','TAG DATA ordinary-column ALTER ADD/DROP','Operation',['TAG DATA ordinary-column ALTER ADD/DROP']),
 ('DEDUPLICATION','TAG automatic deduplication','SQLFeature',['automatic deduplication','deduplication','deduplication']),
]


def occurs(expression,text):
    return bool(re.search(r'(?<![A-Za-z0-9_])'+re.escape(expression)+r'(?![A-Za-z0-9_])',text,re.I))


def catalog(units):
    original=json.loads(Path(__file__).with_name('concept_vocabulary.json').read_text())
    concepts={c['id']:dict(code=c['id'],label=c['canonical_label'],category=c['category'],
        expressions=list(dict.fromkeys([c['canonical_label']]+[e['expression'] for e in c['expressions']])),units=[]) for c in original['concepts']}
    for code in ('TAG_DATA','TAG_METADATA','TAG_STAT'):
        if code in concepts:concepts[code]['category']='DataScope'
    for code,label,category,expressions in EXTRA:
        concepts[code]=dict(code=code,label=label,category=category,expressions=list(dict.fromkeys([label]+expressions)),units=[])
    known={normalize(e) for c in concepts.values() for e in c['expressions']}
    for unit in units:
        if unit['kind']=='example':continue
        for term in re.findall(r'`([A-Za-z_][A-Za-z0-9_]{1,63})`',unit['quote']):
            if normalize(term) in known or re.match(r'(?:ch\d|sensor|example|TEMP_|factory|energy|gps|vehicle|weather)',term,re.I):continue
            # 확인 전 식별자는 후보이며 승인된 의미 관계에 사용될 때만 게시한다.
            code='IDENT_'+hashlib.sha256(normalize(term).encode()).hexdigest()[:12]
            concepts.setdefault(code,dict(code=code,label=term,category='SQLFeature' if term.upper() in ('IN','LIKE','BETWEEN','AVG','MAX','MIN','COUNT','CASE') else 'TechnicalConcept',expressions=[term],units=[]));known.add(normalize(term))
    for concept in concepts.values():
        concept['units']=[u['unit_id'] for u in units if u['kind']!='example' and any(occurs(e,u['quote']+'\n'+u['heading']) for e in concept['expressions'])]
    return {key:value for key,value in concepts.items() if value['units']}


def available(concepts,units):
    text='\n'.join(u['heading']+'\n'+u['quote'] for u in units)
    return {key:value for key,value in concepts.items() if any(occurs(e,text) for e in value['expressions'])}
