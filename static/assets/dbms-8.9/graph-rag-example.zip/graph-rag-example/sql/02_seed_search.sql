-- 이름이 질문에 없어도 질문 전체로 개념·개체 설명을 검색한다.
SELECT R.node_id,R.node_kind,R.label,R.description,
       R.__SEARCH_VECTOR_DISTANCE,R.__SEARCH_TEXT_SCORE,
       R.__SEARCH_SCORE AS seed_score,'HYBRID' AS match_method
FROM HYBRID_SEARCH(
    TABLE GRRAG_NODE AS N,
    VECTOR N.embedding,TEXT N.search_text,
    QUERY_VECTOR TO_VECTOR(:node_query_vector_json,1024),
    QUERY_TEXT :question,
    SPACE 'or-node-v1',METRIC COSINE,MODE EXACT,
    VECTOR_CANDIDATES 100,TEXT_CANDIDATES 100,
    FILTER(
        N.kb_id=:kb_id AND N.state='PUBLISHED'
        AND (N.node_kind='ENTITY' OR (:policy='taxonomy' AND N.node_kind='CLASS'))
        AND EXISTS(
            SELECT 1 FROM GRRAG_EVIDENCE NS,
     GRRAG_CHUNK C,
     GRRAG_DOCUMENT D
WHERE (NS.target_kind='NODE' AND NS.kb_id=N.kb_id AND NS.target_id=N.node_id
              AND D.state='PUBLISHED' AND D.current_version=C.document_version)
  AND (C.chunk_id=NS.chunk_id AND C.kb_id=NS.kb_id)
  AND (D.document_id=C.document_id AND D.kb_id=C.kb_id)
)
    ),
    TOP_K 3
) R
ORDER BY R.__SEARCH_SCORE DESC,R.node_id;
