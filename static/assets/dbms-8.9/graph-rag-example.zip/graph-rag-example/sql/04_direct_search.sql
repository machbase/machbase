-- #4211 직접 문서 검색. 그래프 제한과 관계없는 검색 결과임을 별도 표시한다.
SELECT R.chunk_id,R.body,R.document_id,R.document_version,R.locator,
       D.title,D.source_uri,R.__SEARCH_SCORE AS document_score
FROM HYBRID_SEARCH(
    TABLE GRRAG_CHUNK AS C,VECTOR C.embedding,TEXT C.body,
    QUERY_VECTOR TO_VECTOR(:chunk_query_vector_json,1024),QUERY_TEXT :question,
    SPACE 'or-chunk-v1',METRIC COSINE,MODE EXACT,
    VECTOR_CANDIDATES 100,TEXT_CANDIDATES 100,
    FILTER(
        C.kb_id=:kb_id
        AND EXISTS(
            SELECT 1 FROM GRRAG_DOCUMENT D
            WHERE D.document_id=C.document_id AND D.kb_id=C.kb_id
              AND D.state='PUBLISHED' AND D.current_version=C.document_version
        )
    ),
    TOP_K :document_k
) R,GRRAG_DOCUMENT D
WHERE D.document_id=R.document_id AND D.kb_id=:kb_id
  AND D.state='PUBLISHED' AND D.current_version=R.document_version
ORDER BY R.__SEARCH_SCORE DESC,R.chunk_id;
