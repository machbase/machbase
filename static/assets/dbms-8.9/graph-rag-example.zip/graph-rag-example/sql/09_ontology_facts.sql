-- 시작점의 양방향 관계를 인덱스로 모아 한 번 공유한다. 자기 참조 false step은 행을 추가하지 않는다.
WITH RECURSIVE selected_edges(edge_id,kb_id,source_id,predicate_id,target_id,scope_json) AS (
    SELECT A.edge_id,A.kb_id,A.source_id,A.predicate_id,A.target_id,A.scope_json
    FROM (
        SELECT edge_id,kb_id,source_id,predicate_id,target_id,scope_json
        FROM GRRAG_EDGE
        WHERE kb_id=:kb AND state='APPROVED' AND source_id IN (__SEED_IDS__)
        UNION ALL
        SELECT edge_id,kb_id,source_id,predicate_id,target_id,scope_json
        FROM GRRAG_EDGE
        WHERE kb_id=:kb AND state='APPROVED' AND target_id IN (__SEED_IDS__)
          AND source_id NOT IN (__SEED_IDS__)
    ) A
    UNION ALL
    SELECT edge_id,kb_id,source_id,predicate_id,target_id,scope_json
    FROM selected_edges WHERE 1=0
)
SELECT E.edge_id,E.source_id,S.label AS subject,P.code AS predicate_code,
            E.target_id,T.label AS object_label,E.scope_json,V.quote,C.chunk_id,C.locator,C.body,D.source_uri,D.title
            FROM selected_edges E,GRRAG_NODE S,GRRAG_NODE P,GRRAG_NODE T,
                 GRRAG_EVIDENCE V,GRRAG_CHUNK C,GRRAG_DOCUMENT D
            WHERE E.kb_id=:kb
              AND (E.source_id IN (__SEED_IDS__) OR E.target_id IN (__SEED_IDS__))
              AND S.node_id=E.source_id AND S.kb_id=E.kb_id AND S.state='PUBLISHED'
              AND T.node_id=E.target_id AND T.kb_id=E.kb_id AND T.state='PUBLISHED'
              AND P.node_id=E.predicate_id AND P.kb_id=E.kb_id AND P.node_kind='RELATION_TYPE'
              AND P.code IN ('PART_OF','REQUIRES','SUPPORTS','LIMITED_BY','APPLIES_TO')
              AND V.kb_id=:kb AND V.kb_id=E.kb_id AND V.target_kind='EDGE' AND V.target_id=E.edge_id
              AND C.chunk_id=V.chunk_id AND C.kb_id=V.kb_id
              AND D.document_id=C.document_id AND D.kb_id=C.kb_id
              AND D.state='PUBLISHED' AND D.current_version=C.document_version
            ORDER BY E.edge_id,C.chunk_id,V.evidence_id;
