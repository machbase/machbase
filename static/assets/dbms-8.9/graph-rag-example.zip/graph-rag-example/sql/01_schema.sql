-- 전용 GRRAG_ 이름이 모두 비어 있는 연결에서만 명시적으로 실행한다.
-- #4382 샘플: 일반 사용자 테이블 5개. #4211 Standard 문법 기준 설계.
-- 내부 ID/참조는 LONG(INT64)이며 양수로 발급한다. 같은 참조 도메인의 타입을 일치시킨다.
-- 기존 문자열 문서 키는 external_key로 보존한다. code/label/별칭/URI는 문자열이다.

CREATE TRANSACTION TABLE GRRAG_DOCUMENT (
    document_id LONG PRIMARY KEY,
    kb_id LONG NOT NULL,
    title VARCHAR(256) NOT NULL,
    source_uri VARCHAR(1024) NOT NULL,
    current_version LONG NOT NULL,
    state VARCHAR(16) NOT NULL,
    external_key VARCHAR(256)
);

CREATE TRANSACTION TABLE GRRAG_CHUNK (
    chunk_id LONG PRIMARY KEY,
    kb_id LONG NOT NULL,
    document_id LONG NOT NULL,
    document_version LONG NOT NULL,
    ordinal INTEGER NOT NULL,
    locator VARCHAR(256) NOT NULL,
    body TEXT NOT NULL,
    embedding VECTOR(1024) PROPERTY(EMBEDDING_SPACE='or-chunk-v1'),
    analysis_state VARCHAR(16) NOT NULL,
    extractor_version VARCHAR(128),
    fact_count INTEGER
);

CREATE TRANSACTION TABLE GRRAG_NODE (
    node_id LONG PRIMARY KEY,
    kb_id LONG NOT NULL,
    node_kind VARCHAR(16) NOT NULL,
    label VARCHAR(256) NOT NULL,
    code VARCHAR(64),
    description VARCHAR(2048),
    search_text TEXT,
    state VARCHAR(16) NOT NULL,
    embedding VECTOR(1024) PROPERTY(EMBEDDING_SPACE='or-node-v1'),
    canonical_id LONG,
    label_key VARCHAR(256),
    source_kind VARCHAR(16),
    target_kind VARCHAR(16)
);

CREATE TRANSACTION TABLE GRRAG_EDGE (
    edge_id LONG PRIMARY KEY,
    kb_id LONG NOT NULL,
    source_id LONG,
    predicate_id LONG,
    target_id LONG,
    state VARCHAR(16) NOT NULL,
    subject_text VARCHAR(256),
    predicate_text VARCHAR(128),
    object_text VARCHAR(256),
    extractor_version VARCHAR(128),
    canonical_edge_id LONG,
    scope_json TEXT
);

CREATE TRANSACTION TABLE GRRAG_EVIDENCE (
    evidence_id LONG PRIMARY KEY,
    kb_id LONG NOT NULL,
    target_kind VARCHAR(8) NOT NULL,
    target_id LONG NOT NULL,
    chunk_id LONG NOT NULL,
    quote VARCHAR(2048) NOT NULL
);

CREATE INDEX GRRAG_NODE_ALIAS_LOOKUP ON GRRAG_NODE(kb_id,node_kind,label_key) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_NODE_KIND ON GRRAG_NODE(kb_id,node_kind) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_NODE_CODE ON GRRAG_NODE(kb_id,node_kind,code) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_EDGE_OUT ON GRRAG_EDGE(kb_id,source_id,predicate_id) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_EDGE_IN ON GRRAG_EDGE(kb_id,target_id,predicate_id) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_EVIDENCE_TARGET ON GRRAG_EVIDENCE(kb_id,target_kind,target_id,chunk_id) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_EVIDENCE_CHUNK ON GRRAG_EVIDENCE(kb_id,chunk_id,target_kind,target_id) INDEX_TYPE BTREE;
CREATE INDEX GRRAG_CHUNK_DOCUMENT ON GRRAG_CHUNK(kb_id,document_id,document_version) INDEX_TYPE BTREE;

CREATE INDEX GRRAG_NODE_BM25 ON GRRAG_NODE(search_text) INDEX_TYPE BM25 ANALYZER='CJK_EN';
CREATE INDEX GRRAG_CHUNK_BM25 ON GRRAG_CHUNK(body) INDEX_TYPE BM25 ANALYZER='CJK_EN';
ALTER INDEX GRRAG_NODE_BM25 WAIT TIMEOUT 60;
ALTER INDEX GRRAG_CHUNK_BM25 WAIT TIMEOUT 60;
