# 검색 SQL과 탐색 범위

일반 질문의 기본 `context` 정책은 `PART_OF`, `REQUIRES`, `APPLIES_TO`,
`SUPPORTS`, `LIMITED_BY`, `RELATED_TO` 여섯 관계를 양방향으로 탐색한다.
`F`와 `R`은 저장된 관계의 원래 방향을 보존하므로 역방향 탐색을 정방향 명제로
해석하지 않는다. 직접 문서 검색의 범위에는 이 그래프 정책을 적용하지 않는다.
자동 seed의 HYBRID 검색과 정확한 별칭의 canonical 후보 역시 기본 context에서는
게시된 ENTITY만 허용한다. taxonomy에서는 CLASS 후보도 포함한다. 그래프의 읽기 가능
노드에도 같은 조건을 적용하므로 명시한 CLASS seed가 기본 정책을 우회하지 않는다.

사용자가 분류 확장을 명시하면 `taxonomy` 정책으로 `INSTANCE_OF`와
`SUBCLASS_OF`를 추가한다. 같은 CLASS에 속한 ENTITY는
`ENTITY → CLASS ← ENTITY` 두 hop으로 대량 연결될 수 있다. 기본 문맥 검색에서
이 경로를 허용하면 후보 문서가 거의 전체 코퍼스로 넓어져 관계 탐색의 범위 제한이
약해질 수 있다. taxonomy는 이를 의도한 검색이며 시간 단축을 위한 숨은 제한이 아니다.
두 정책 모두 요청한 깊이 안의 경로를 처리하며 별도의 frontier/결과 행 수 절단은 없다.

`policy`는 앱에서 `context`/`taxonomy`만 허용하고 SQL의 `:policy`에 바인딩한다.
LLM이 만든 임의 SQL이나 predicate를 문자열로 연결하지 않는다. 기본값과 선택한 정책은
`search`의 trace 및 `explain_search` 결과에 남는다. 개념 seed 발견은 두 정책 모두
정확한 별칭 확인 후 HYBRID로 보충하되, 허용하는 node_kind 범위는 위 정책을 따른다.

## 실행 계획과 성능의 확인 범위

기본 `graph_strategy='shared'`는 `shared_query.py`가 고정 출력 필드 목록을 확인한 뒤
원본 `03_graph_search.sql`의 공통 CTE에 `UNION ALL SELECT ... FROM 자신 WHERE 1=0`을
붙여 기존 #4382의 공유 producer를 사용한다. false 분기는 행을 추가하지 않는다.
`arcs`와 `candidate_routes`의 compound 전체는 별도 anchor SELECT로 감싼다.
실제로 순환 그래프를 반복 탐색하는 것은 원래 `walk`뿐이며 그 깊이·노드 방문 검사와
후보·대표 경로·관계 근거 조건은 바꾸지 않는다. 새로운 SQL 문법이나 엔진 기능은 없다.
중간 결과는 같은 statement와 읽기 snapshot 안에서 한 번 생성되어 여러 reader가 읽는다.
기존 실행 메모리 한도를 사용하며 큰 중간 집합에 대한 무한 메모리를 보장하지 않는다.

`06_graph_search_shared.sql`은 이 생성 결과를 검토·배포하기 위한 템플릿이며 동기화
단위 테스트로 원본과의 일치를 검사한다. 질문·벡터·ID 값은 생성기에 전달하지 않고
기존 named bind만 유지한다. `graph_strategy='inline'`은 원본 전략을 비교용으로 실행한다.
선택 전략과 실제 SQL 파일은 검색 trace와 EXPLAIN 결과에 기록한다.

`01_schema.sql`은 관계의 양방향 BTREE, 근거 target/chunk BTREE와 BM25를 만든다.
인덱스가 존재한다는 사실만으로 재귀 frontier의 실제 인덱스 접근을 증명하지 않는다.
`03_graph_search.sql`의 `arcs`는 UNION ALL view이고 그 아래 `readable_edges`는 여러
관계를 JOIN한다. 현재 optimizer의 view predicate pushdown 제한 때문에 frontier 조건이
실제 EDGE source/target 인덱스까지 전달되지 않고 하위 view를 반복 평가할 가능성이 있다.
대표 경로와 원문 근거를 반환하는 후속 CTE의 인라인 확장 비용도 확인해야 한다.

사용자가 지정한 대상 DB에서 원래 SQL과 bind, 일반 EXPLAIN 및 EXPLAIN FULL,
실제 시간을 함께 보존하여 확인한다. `MODE EXACT`의 검색 후보 읽기는 예상 비용이며,
EDGE/EVIDENCE 등 구조 JOIN의 FULL SCAN과 구분한다. 계획 문자열의 FULL SCAN 목록만으로
물리 I/O나 반복 횟수를 단정하지 않는다. 정책 분리의 검색 범위는 코드·fake 테스트로
검사했다. 선별 smoke fixture에서 root가 원본 12행과 공유 전략 12행의 일치를 확인하고,
관측 시간 약 0.758초 대 0.024~0.025초 및 SCAN_OPEN 10274 대 43을 기록했다.
이는 작은 fixture의 native 관측이며 전체 코퍼스 성능이나 SLA를 증명하지 않는다.
생성기와 API를 연결한 최종 코드의 prepared 재사용·oracle·실제 계획은 별도 native
검증으로 확인해야 한다. 해당 코드나 대상 데이터의 실행 전 상태를 PASS로 추측하지 않는다.

## 원문 대조 의미 온톨로지(schema2)

현재 기본 자료는 RELATED_TO/Rule 위주인 이전 span 자료를 대체한다.
의미 관계는 PART_OF/REQUIRES/SUPPORTS/LIMITED_BY/APPLIES_TO5종이다.
EDGE.scope_json TEXT에 주 명제·원문 절 제목·조건·대조 원문을 저장한다.
07_graph_search_scoped.sql과08_graph_search_scoped_shared.sql은 기존03/06과
동일한 검색 흐름으로 범위를 함께 반환한다. schema1 자료는 기존 SQL을 사용한다.
05번은 실제 ALIAS와 ENTITY.label_key를 함께 조회한다. 정규 이름 자체의 별칭은 불필요하다.
09_ontology_facts.sql은 시작점 인접 승인 명제와 현재 공개 버전 근거를 한 statement로
반환한다. 양방향 EDGE 인덱스로 시작점 관계를 수집·공유하고 EVIDENCE target 인덱스로
읽어, 전체 근거를 먼저 순회하던 실행 계획을 방지한다. 문서 Top-K SQL과는 별도의 읽기이며 trace에 SQL·바인딩·시간을 남긴다.
최종 실제 플랜·단위/회귀 검증 결과는 상위 report.md에 기록했다.
