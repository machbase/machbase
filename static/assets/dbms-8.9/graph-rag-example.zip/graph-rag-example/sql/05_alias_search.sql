SELECT * FROM (
SELECT N.node_id,N.node_kind,N.label,N.description,
       N.label_key AS matched_alias,CAST(1 AS DOUBLE) AS seed_score,
       'EXACT_NAME' AS match_method
FROM GRRAG_NODE N
WHERE N.kb_id=:kb_id AND N.state='PUBLISHED' AND N.label_key IN (__ALIAS_KEYS__)
  AND (N.node_kind='ENTITY' OR (:policy='taxonomy' AND N.node_kind='CLASS'))
  AND EXISTS(SELECT 1 FROM GRRAG_EVIDENCE NS,GRRAG_CHUNK C,GRRAG_DOCUMENT D
      WHERE NS.kb_id=N.kb_id AND NS.target_kind='NODE' AND NS.target_id=N.node_id
        AND C.chunk_id=NS.chunk_id AND C.kb_id=NS.kb_id
        AND D.document_id=C.document_id AND D.kb_id=C.kb_id
        AND D.state='PUBLISHED' AND D.current_version=C.document_version)
UNION ALL
-- #4211 사용. 먼저 정확한 코드/별칭을 조회한다.
-- alias_key는 앱이 적재 때와 같은 NFC/대소문자 정책으로 정규화한 값이다.
SELECT N.node_id,N.node_kind,N.label,N.description,
       A.label_key AS matched_alias,CAST(1 AS DOUBLE) AS seed_score,
       'EXACT_ALIAS' AS match_method
FROM GRRAG_NODE A,
     GRRAG_NODE N
WHERE (A.node_kind='ALIAS' AND A.state='PUBLISHED' AND A.kb_id=:kb_id AND A.label_key IN (__ALIAS_KEYS__)
  AND N.state='PUBLISHED'
  AND (N.node_kind='ENTITY' OR (:policy='taxonomy' AND N.node_kind='CLASS'))
  AND EXISTS(
      SELECT 1 FROM GRRAG_EVIDENCE AE,
     GRRAG_CHUNK C,
     GRRAG_DOCUMENT D
WHERE (AE.kb_id=A.kb_id AND AE.target_kind='NODE' AND AE.target_id=A.node_id
        AND D.state='PUBLISHED' AND D.current_version=C.document_version)
  AND (C.chunk_id=AE.chunk_id AND C.kb_id=AE.kb_id)
  AND (D.document_id=C.document_id AND D.kb_id=C.kb_id)
)
  AND EXISTS(
      SELECT 1 FROM GRRAG_EVIDENCE NS,
     GRRAG_CHUNK C,
     GRRAG_DOCUMENT D
WHERE (NS.target_kind='NODE' AND NS.kb_id=N.kb_id AND NS.target_id=N.node_id
        AND D.state='PUBLISHED' AND D.current_version=C.document_version)
  AND (C.chunk_id=NS.chunk_id AND C.kb_id=NS.kb_id)
  AND (D.document_id=C.document_id AND D.kb_id=C.kb_id)
))
  AND (N.node_id=A.canonical_id AND N.kb_id=A.kb_id)
) MATCHES
ORDER BY matched_alias,node_id;
