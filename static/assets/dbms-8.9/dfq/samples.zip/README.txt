Generated synthetic sensor samples: id=1..5; v=id*10; COUNT=5, SUM(id)=15, SUM(v)=150.
